import java.util.Map;
import java.util.stream.Collectors;

public class NewStream {

    public static void main(String[] args) {
        String str = "javaee";
         Map<Character, Long> mapcount = str.chars()
           .mapToObj(c->(char)c)
           .collect(Collectors.groupingBy(c->c,Collectors.counting()));
         
         System.out.println(mapcount);
    }

}
