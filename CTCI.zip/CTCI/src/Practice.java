//Given an integer array nums, return all the triplets [nums[i], nums[j], nums[k]] such that i != j, i != k, and j != k,
//and nums[i] + nums[j] + nums[k] == 0.
//Notice that the solution set must not contain duplicate triplets.
//
//Example 1:
//Input: nums = [-1,0,1,2,-1,-4]
//Output: [[-1,-1,2],[-1,0,1]]
//Example 2:
//Input: nums = []
//Output: []
//Example 3:
//Input: nums = [0]
//Output: []

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Practice{
    
    public static Set<List<Integer>> tripletSumZero(int arr[]) {
        Set<List<Integer>> result = new HashSet<>();
        Set<Integer> twoSum = new HashSet<>();
        for(int num : arr) {
            twoSum.add(num);
        }
        for(int i=1; i<arr.length; i++) {
            int sum = arr[i]+arr[i-1];
            if(twoSum.contains(-sum)) {
                List<Integer> output = new ArrayList<>();
                output.add(arr[i-1]);
                output.add(arr[i]);
                output.add(-sum);
                result.add(output);
            }
        }
        
            
        return result; 
        
    }
    public static void main(String s[]) {
        int arr[] = {-1,0,1,2,-1,-4,-1,0,1,2,-1,-4};
        Set<List<Integer>> result =  tripletSumZero(arr);
        for(List<Integer> re: result) {
            System.out.println(re);
               
        }
//        System.out.println("result "+result.get(0).get(1));   
        
    }
    
    
}
        
        