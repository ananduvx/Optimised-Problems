import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class NewTestKPMG {
//    “java is just a programming language” o/p = v
    
//    to group the last name and the no. of occurrences in the list.
//    Input - Full name list -> {Ravi Kumar, Neha Gupta, Arti Gupta, Kamal Rai}
//    Output - Kumar - 1, Gupta - 2, Rai – 1
    
    
    
//    program to get a response as Excel column name for integer input.
//    Input 1 -> A, 26 -> Z, 27 -> AA....,52-> AZ, 53 -> BA...703 -> AAA
    
    public static void main(String args[]) {
        String s = "java is just a programming language";
        String [] str = {"Ravi Kumar", "Neha Gupta", "Arti Gupta", "Kamal Rai"};
        int input = 27;
        System.out.println(responseColumn(input));
        
//        System.out.println(printOccurance(Arrays.asList(str)));
//        System.out.println(printNonRepeatingChar(s));
    }

private static String responseColumn(int input) {
    StringBuilder strBuild = new StringBuilder();
    while(input>0) {
        int reminder = (input-1)%26;
        char charTOAdd = (char)(reminder +'A');
        strBuild.append(charTOAdd);
        input = input/26;
    }  
    return strBuild.toString();
}

private static Map<String,Long> printOccurance(List<String> asList) {
            return asList.stream()
                    .map(name->name.split(" "))
                    .filter(len-> len.length >1)
                    .collect(Collectors.groupingBy(part->part[part.length-1],Collectors.counting()));
}

private static char printNonRepeatingChar(String s) {
    Map<Character, Integer> charFre = new HashMap<>();
    for(char c: s.toCharArray()) {
        charFre.put(c, charFre.getOrDefault(c,0)+1);
    }
    for(char c: s.toCharArray()) {
        if(charFre.get(c) == 1) {
            return c;
        }
    }
    return 0;
}
}


//final String pwd= "abc"
//pwd= "def"




