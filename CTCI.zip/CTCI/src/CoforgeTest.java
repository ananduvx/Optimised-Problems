
public class CoforgeTest {
    public static void main(String args[]) {
        for(int i=0; i<3; i++) {
            Thread thread = new Thread(new PrintNumber(i));
            thread.start();
        }  
    }

}
class PrintNumber implements Runnable {
    private final int threadNum;
    public PrintNumber(int threadNum) {
        this.threadNum = threadNum;
        
    }
    @Override
    public void run() {
        ServiceCall.print(3);
        System.out.println();
    }
  
}
class ServiceCall{
    private static final Object lock= new Object();
    private static int count=1;
    public static void print(int threadNum) {
        while(count<=10) {
            synchronized (lock) {
                System.out.println(Thread.currentThread().getName()+" -- "+ count);
            }
            count++;
        }
    }
}










