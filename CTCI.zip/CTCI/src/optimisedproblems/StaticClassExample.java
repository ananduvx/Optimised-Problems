package optimisedproblems;


public class StaticClassExample {
        public static boolean isPalindrome(String str) {
            int left = 0;
            int right = str.length() - 1;

            while (left < right) {
                if (str.charAt(left++) != str.charAt(right--)) {
                    return false;
                }
            }

            return true;
        }

        public static void main(String[] args) {
            String str = "madam";
            boolean isPalindrome = isPalindrome(str);
            if (isPalindrome) {
                System.out.println("The string is a palindrome.");
            } else {
                System.out.println("The string is not a palindrome.");
            }
        }
    }
//    Stream Api to add odd numbers. 
//     public static void main(String []args){
//     Integer[] arr = {1, 2,3,4, 5,8, 7, 9};
//      int sum = Arrays.asList(arr).stream()
//             .filter(a-> a%2 !=0)
//             .mapToInt(Integer::intValue)
//             .sum();     
//      System.out.println(sum);
//     }