package optimisedproblems.strings.hard;

public class WordWrap {
    public static void wordWrap(String[] words, int lineWidth) {
        int n = words.length;
        int[] dp = new int[n];
        int[] breaks = new int[n];

        // Calculate the extra space for each line
        int[] extraSpace = new int[n];
        for (int i = 0; i < n; i++) {
            extraSpace[i] = lineWidth - words[i].length();
            for (int j = i + 1; j < n; j++) {
                extraSpace[i] -= words[j].length() + 1;
            }
        }

        // Calculate the optimal solution using dynamic programming
        dp[0] = extraSpace[0] >= 0 ? extraSpace[0] * extraSpace[0] : Integer.MAX_VALUE;
        for (int i = 1; i < n; i++) {
            dp[i] = Integer.MAX_VALUE;
            for (int j = 0; j <= i; j++) {
                if (extraSpace[j] >= 0 && dp[j - 1] != Integer.MAX_VALUE
                        && (dp[j - 1] + extraSpace[j] * extraSpace[j] < dp[i])) {
                    dp[i] = dp[j - 1] + extraSpace[j] * extraSpace[j];
                    breaks[i] = j - 1;
                }
            }
        }

        // Print the word wrap solution
        printWordWrap(words, breaks, n - 1);
    }

    private static void printWordWrap(String[] words, int[] breaks, int i) {
        if (i >= 0) {
            printWordWrap(words, breaks, breaks[i]);
            for (int j = breaks[i] + 1; j <= i; j++) {
                System.out.print(words[j] + " ");
            }
            System.out.println();
        }
    }

    public static void main(String[] args) {
        String[] words = { "This", "is", "an", "example", "of", "word", "wrap", "problem" };
        int lineWidth = 10;

        wordWrap(words, lineWidth);
    }
}
