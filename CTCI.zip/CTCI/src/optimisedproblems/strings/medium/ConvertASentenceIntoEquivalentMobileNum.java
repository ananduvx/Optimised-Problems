package optimisedproblems.strings.medium;

/**
 * T.c-O(n).
 * 
 * @author Anand
 *
 */
public class ConvertASentenceIntoEquivalentMobileNum {

    public static String convertToKeypadSequence(String sentence) {
        StringBuilder keypadSequence = new StringBuilder();
        for (char c : sentence.toCharArray()) {
            c = Character.toLowerCase(c);
            if (Character.isLetter(c)) {
                int asciiValue = (int) c;
                int digit = (asciiValue - (int) 'a') / 3 + 2;
                if (c == 's' || c == 'v' || c == 'y' || c == 'z') {
                    digit++;
                }
                keypadSequence.append(digit);
            } else if (c == ' ') {
                keypadSequence.append('0');
            }
        }
        return keypadSequence.toString();
    }

    public static void main(String[] args) {
        String sentence = "Hello world";
        String keypadSequence = convertToKeypadSequence(sentence);
        System.out.println(keypadSequence);
    }
}
