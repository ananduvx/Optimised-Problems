package optimisedproblems.strings.medium;

//Using Two pointer approach 
public class StringIsValidShuffleOfTwoStringOrNot {
    public static boolean isValidShuffle(String str, String str1, String str2) {
        int len1 = str1.length();
        int len2 = str2.length();
        int len = str.length();
        //Base condition
        if (len != len1 + len2) {
            return false;
        }
        int i = 0; // Index for str1
        int j = 0; // Index for str2
        for (int k = 0; k < len; k++) {
            if (i < len1 && str.charAt(k) == str1.charAt(i)) {
                i++;
            }
            else if (j < len2 && str.charAt(k) == str2.charAt(j)) {
                j++;
            }
            else {
                return false;
            }
        }
        return (i == len1 && j == len2);
    }

    public static void main(String[] args) {
        String str = "abcxyz";
        String str1 = "abc";
        String str2 = "xyz";
        if (isValidShuffle(str, str1, str2)) {
            System.out.println(str + " is a valid shuffle of " + str1 + " and " + str2);
        } else {
            System.out.println(str + " is not a valid shuffle of " + str1 + " and " + str2);
        }
    }
}