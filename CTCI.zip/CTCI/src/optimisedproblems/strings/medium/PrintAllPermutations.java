package optimisedproblems.strings.medium;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Total permutation count of a string of length n is n!
 * Height of tree is equal to lenght of that string 
 * 
 * @author Anand
 *
 */
public class PrintAllPermutations {
        public static List<String> uniquePermutations(String string) {
            List<String> result = new ArrayList<>();
            char[] chars = string.toCharArray();
            Arrays.sort(chars);  // Sort the input string
            boolean[] used = new boolean[string.length()];
            permuteHelper(chars, "", used, result);
            return result;
        }
        private static void permuteHelper(char[] chars, String currentPermutation, boolean[] used, List<String> result) {
            if (currentPermutation.length() == chars.length) {
                result.add(currentPermutation);
            } else {
                Set<Character> uniqueChars = new HashSet<>();
                for (int i = 0; i < chars.length; i++) {
                    if (used[i] || uniqueChars.contains(chars[i])) {
                        continue;
                    }
                    used[i] = true;
                    uniqueChars.add(chars[i]);
                    permuteHelper(chars, currentPermutation + chars[i], used, result);
                    used[i] = false;
                }
            }
        }

        public static void main(String[] args) {
            String inputString = "aba";
            List<String> permutationsList = uniquePermutations(inputString);
            System.out.println(permutationsList);
        }
    }