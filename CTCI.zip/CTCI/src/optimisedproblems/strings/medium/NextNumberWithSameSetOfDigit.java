package optimisedproblems.strings.medium;

import java.util.Arrays;

/**
 * or the next permutations. O(n) S.C - O(1).
 * 
 * @author Anand
 *
 */
public class NextNumberWithSameSetOfDigit {
    public static int findNextGreaterNumber(int number) {
        // Convert the number to an array of digits
        char[] digits = Integer.toString(number).toCharArray();

        int n = digits.length;

        // Start from the rightmost digit and find the pivot
        int i;
        for (i = n - 1; i > 0; i--) {
            if (digits[i] > digits[i - 1]) {
                break;
            }
        }
        // If there is no pivot, the current number is the largest possible
        if (i == 0) {
            return -1; // Indicate that no greater number is possible
        }
        // Find the smallest digit to the right of the pivot that is larger than the pivot
        int pivot = digits[i - 1];
        int smallestIndex = i;
        for (int j = i + 1; j < n; j++) {
            if (digits[j] > pivot && digits[j] < digits[smallestIndex]) {
                smallestIndex = j;
            }
        }

        // Swap the pivot and the successor
        char temp = digits[i - 1];
        digits[i - 1] = digits[smallestIndex];
        digits[smallestIndex] = temp;

        // Sort the digits to the right of the pivot in ascending order
        Arrays.sort(digits, i, n);

        // Convert the updated digits array back to an integer
        int result = Integer.parseInt(new String(digits));

        return result;
    }

    public static void main(String[] args) {
        int number = 534976;
        int result = findNextGreaterNumber(number);
        System.out.println("Next greater number: " + result);
    }
}
