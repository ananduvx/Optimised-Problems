package optimisedproblems.strings.medium;

/**
 * Given a string S consisting of only opening and closing curly brackets '{' and '}', find out the minimum number of
 * reversals required to convert the string into a balanced expression. A reversal means changing '{' to '}' or
 * vice-versa.
 * 
 * @author Anand
 *
 */
public class CountTheReversal {
    public static int countReversals(String input) {
        // Reversals not possible for odd-length strings
        if (input.length() % 2 != 0) {
            return -1;
        }

        int openCount = 0; // Count of '{' characters encountered
        int reversalCount = 0; // Count of reversals needed

        for (char ch : input.toCharArray()) {
            if (ch == '{') {
                openCount++;
            } else if (ch == '}') {
                if (openCount > 0) {
                    // Match found, decrease the openCount
                    openCount--;
                } else {
                    // Reversal needed, increment the reversalCount
                    reversalCount++;
                    openCount++;
                }
            }
        }

        // The total number of reversals needed is half of the openCount
        reversalCount += openCount / 2;
        return reversalCount;
    }

    public static void main(String[] args) {
        String input = "{{}{{}{}{}";
        int result = countReversals(input);
        System.out.println("Number of reversals: " + result);
    }
}
