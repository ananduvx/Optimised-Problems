package optimisedproblems.strings.medium;

public class EditDistance {
    public static int calculateEditDistance(String str1, String str2) {
        int m = str1.length();
        int n = str2.length();

        // Create a 2D array to store the edit distances
        int[][] dp = new int[m + 1][n + 1];

        // Initialize the first row and first column
        for (int i = 0; i <= m; i++) {
            dp[i][0] = i;
        }

        for (int j = 0; j <= n; j++) {
            dp[0][j] = j;
        }

        // Calculate the edit distance
        for (int i = 1; i <= m; i++) {
            for (int j = 1; j <= n; j++) {
                if (str1.charAt(i - 1) == str2.charAt(j - 1)) {
                    dp[i][j] = dp[i - 1][j - 1];
                } else {
                    dp[i][j] = Math.min(dp[i - 1][j - 1] + 1, // substitution
                                           Math.min(dp[i][j - 1] + 1, // insertion
                                                          dp[i - 1][j] + 1)); // deletion
                }
            }
        }

        return dp[m][n];
    }

    public static void main(String[] args) {
        String str1 = "kitten";
        String str2 = "sitting";

        int editDistance = calculateEditDistance(str1, str2);
        System.out.println("Edit distance between \"" + str1 + "\" and \"" + str2 + "\" is: " + editDistance);
    }
}
//Create a 2D array dp of size (m+1) x (n+1).
//•   dp[i][j] represents the edit distance between the first i characters of string1 and the first j characters of string2.
//2   Initialize the first row and first column of dp:
//•   dp[0][j] = j for j from 0 to n.
//•   dp[i][0] = i for i from 0 to m.
//3   Iterate through the characters of string1 and string2:
//•   For i from 1 to m:
//•   For j from 1 to n:
//•   If string1[i-1] is equal to string2[j-1], set cost = 0; otherwise, set cost = 1.
//•   dp[i][j] = minimum of:
//•   dp[i-1][j] + 1 (deletion)
//•   dp[i][j-1] + 1 (insertion)
//•   dp[i-1][j-1] + cost (substitution)
//4   Return dp[m][n], which represents the minimum edit distance between string1 and string2.