package optimisedproblems.strings.medium;

public class CountPallendromicSubsequence {
    public static int countPalindromicSubsequences(String str) {
        int n = str.length();
        int[][] dp = new int[n][n];

        // Initialize diagonal elements to 1
        for (int i = 0; i < n; i++) {
            dp[i][i] = 1;
        }

        // Fill the remaining elements of dp[][] in a bottom-up manner
        for (int len = 2; len <= n; len++) {
            for (int i = 0; i < n - len + 1; i++) {
                int j = i + len - 1;
                if (str.charAt(i) == str.charAt(j)) {
                    dp[i][j] = dp[i + 1][j] + dp[i][j - 1] + 1;
                } else {
                    dp[i][j] = dp[i + 1][j] + dp[i][j - 1] - dp[i + 1][j - 1];
                }
            }
        }

        return dp[0][n - 1];
    }

    public static void main(String[] args) {
        String str = "abbcba";
        int result = countPalindromicSubsequences(str);
        System.out.println("Count of palindromic subsequences: " + result);
    }
}
