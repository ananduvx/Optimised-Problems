package optimisedproblems.strings.set1;
/**
 * Pattern matching or String matching algo. 
 * @author Anand
 *
 */
public class RabinKarpALgo {
//it uses rolling hash algorithm. 
// find hashCode and match it if it matches check for the equals then return. 
    //T.c -- O(mn).
}
