package optimisedproblems.strings.set1;

public class PallindromeChecker {
    /**
     * use two pointer approach
     * 
     * @param str
     * @return
     */
    public static boolean isPalindrome(String str) {
        int left = 0;
        int right = str.length() - 1;
        while (left < right) {
            if (str.charAt(left++) != str.charAt(right--)) {
                return false;
            }
        }
        return true;
    }

    public static void main(String[] args) {
        String str = "madama";
        boolean isPalindrome = isPalindrome(str);
        if (isPalindrome) {
            System.out.println("The string is a palindrome.");
        } else {
            System.out.println("The string is not a palindrome.");
        }
    }
}