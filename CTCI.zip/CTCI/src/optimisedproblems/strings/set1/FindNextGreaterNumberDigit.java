package optimisedproblems.strings.set1;

public class FindNextGreaterNumberDigit {
    public static void findNextGreaterNumber(char[] digits) {
        int n = digits.length;

        // Step 1: Find the digit to be replaced
        int i;
        for (i = n - 1; i > 0; i--) {
            if (digits[i] > digits[i - 1]) {
                break;
            }
        }

        // Step 2: If no pair found, number is already largest
        if (i == 0) {
            System.out.println("No greater number possible.");
            return;
        }

        // Step 3: Find smallest digit greater than digits[i-1]
        int x = digits[i - 1];
        int smallest = i;
        for (int j = i + 1; j < n; j++) {
            if (digits[j] > x && digits[j] < digits[smallest]) {
                smallest = j;
            }
        }

        // Step 4: Swap the digits
        char temp = digits[i - 1];
        digits[i - 1] = digits[smallest];
        digits[smallest] = temp;

        // Step 5: Reverse the remaining digits
        reverse(digits, i, n - 1);

        // Print the next greater number
        System.out.print("Next greater number: ");
        for (char digit : digits) {
            System.out.print(digit);
        }
        System.out.println();
    }

    private static void reverse(char[] digits, int start, int end) {
        while (start < end) {
            char temp = digits[start];
            digits[start] = digits[end];
            digits[end] = temp;
            start++;
            end--;
        }
    }

    public static void main(String[] args) {
        char[] digits = { '5', '3', '4', '9', '7', '6' };
        findNextGreaterNumber(digits);
    }
}

/**
 * 
1   Start from the rightmost digit and search for the first pair of digits (i, i-1) where digit i-1 is smaller than digit i. 
This digit i-1 will be the digit to be replaced.
2   If no such pair is found, it means the digits are in descending order, and there is no greater number possible. 
In this case, the number itself is the largest possible number using the same set of digits.
3   If a pair (i, i-1) is found, find the smallest digit greater than digit i-1 to the right of digit i-1.
 This digit will be swapped with digit i-1.
4   Reverse the digits to the right of digit i-1.
 */
