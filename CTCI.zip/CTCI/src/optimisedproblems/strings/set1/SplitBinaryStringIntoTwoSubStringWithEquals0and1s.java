package optimisedproblems.strings.set1;

import java.util.ArrayList;
import java.util.List;

/**
 * O(n).
 * 
 * @author Anand
 *
 */
public class SplitBinaryStringIntoTwoSubStringWithEquals0and1s {

    public static List<String> splitBinaryString(String binaryString) {
        List<String> result = new ArrayList<>();
        int count0 = 0;
        int count1 = 0;
        int start = 0;
        for (int i = 0; i < binaryString.length(); i++) {
            char c = binaryString.charAt(i);
            if (c == '0')
                count0++;
            else if (c == '1')
                count1++;
            if (count0 == count1) {
                result.add(binaryString.substring(start, i + 1));
                start = i + 1;
                count0 = 0;
                count1 = 0;
            }
        }
        return result;
    }

    public static void main(String[] args) {
        String binaryString = "110001011100";
        List<String> result = splitBinaryString(binaryString);
        System.out.println(result);
    }
}