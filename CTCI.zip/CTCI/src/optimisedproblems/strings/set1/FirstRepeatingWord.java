package optimisedproblems.strings.set1;

import java.util.HashSet;

public class FirstRepeatingWord {
    public static String findFirstRepeatingWord(String sentence) {
        String[] words = sentence.split("\\s+");

        HashSet<String> set = new HashSet<>();

        for (String word : words) {
            if (!set.add(word)) {
                return word;
            }
        }

        return ""; // If no repeating word is found
    }

    public static void main(String[] args) {
        String sentence = "This is a sample sentence with a repeating word. The word is 'a'.";

        String result = findFirstRepeatingWord(sentence);
        if (!result.isEmpty()) {
            System.out.println("First repeating word: " + result);
        } else {
            System.out.println("No repeating word found.");
        }
    }
}
