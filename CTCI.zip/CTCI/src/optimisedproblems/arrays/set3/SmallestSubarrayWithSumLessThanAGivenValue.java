package optimisedproblems.arrays.set3;

public class SmallestSubarrayWithSumLessThanAGivenValue {

    public static int smallestSubarraySum(int[] nums, int target) {
        int minLength = Integer.MAX_VALUE; // Initialize the minimum length as a large value
        int sum = 0;
        int start = 0;

        for (int end = 0; end < nums.length; end++) {
            sum += nums[end]; // Add the current element to the sum
            // Shrink the window from the start if the sum is greater than the target
            while (sum > target) {
                minLength = Math.min(minLength, end - start + 1); // Update the minimum length
                sum -= nums[start]; // Remove the element at the start pointer from the sum
                start++; // Move the start pointer
            }
        }

        return (minLength != Integer.MAX_VALUE) ? minLength : 0; // Return the minimum length or 0 if no subarray found
    }
}