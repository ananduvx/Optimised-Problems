package optimisedproblems.arrays.set3;

import java.util.Arrays;

public class SecondLargestElement {

    public static int findSecondMaximum(int[] array) {
        int max = Integer.MIN_VALUE; // Maximum element
        int secondMax = Integer.MIN_VALUE; // Second maximum element

        for (int num : array) {
            if (num > max) {
                // Update both maximum and second maximum
                secondMax = max;
                max = num;
            } else if (num > secondMax && num != max) {
                // Update only the second maximum
                secondMax = num;
            }
        }

        return secondMax;
    }

    public static void main(String[] args) {
        int[] array = { 5, 2, 7, 1, 9, 3 };
        System.out.println("Array: " + Arrays.toString(array));

        int secondMax = findSecondMaximum(array);
        System.out.println("Second maximum: " + secondMax);
    }
}
