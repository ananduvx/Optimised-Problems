package optimisedproblems.arrays.set3;

import java.util.Arrays;

public class ChacolateDistributionProblem {

    public static int findMinDifference(int[] chocolates, int students) {
        int n = chocolates.length;

        // If the number of students is less than or equal to 0, return 0
        if (students <= 0 || n == 0) {
            return 0;
        }

        // Sort the array in ascending order
        Arrays.sort(chocolates);

        // Initialize the minimum difference as maximum possible value
        int minDifference = Integer.MAX_VALUE;

        // Find the minimum difference by sliding the window
        for (int i = 0, j = students - 1; j < n; i++, j++) {
            int difference = chocolates[j] - chocolates[i];
            if (difference < minDifference) {
                minDifference = difference;
            }
        }

        return minDifference;
    }

    public static void main(String[] args) {
        int[] chocolates = { 3, 4, 1, 9, 56, 7, 9, 12 };
        int students = 5;

        int minDifference = findMinDifference(chocolates, students);
        System.out.println("Minimum Difference: " + minDifference);
    }
}