package optimisedproblems.arrays.Set1;

/**
 * Input: intervals = [[1,3],[2,6],[8,10],[15,18]]
 *Output: [[1,6],[8,10],[15,18]]
 *Explanation: Since intervals [1,3] and [2,6] overlap, merge them into [1,6].
 *use greedy approach. 
 */

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class MergeInterval {
    //Steps:--
    public static int[][] mergeIntervals(int[][] intervals) {
        // Sort the intervals based on the start time
        Arrays.sort(intervals, Comparator.comparingInt(a -> a[0]));
        List<int[]> merged = new ArrayList<>(); 
        //2. take the first from the sorted one and add it in the merged List. 
        int[] currentInterval = intervals[0]; //{ 1, 3 }
        merged.add(currentInterval);
        for (int[] interval : intervals) {
            int currentEnd = currentInterval[1];   //3
            int nextStart = interval[0];    // 1
            int nextEnd = interval[1];     // 3
            if (currentEnd >= nextStart) {
                // Overlapping intervals, update the end time
                currentInterval[1] = Math.max(currentEnd, nextEnd);
            } else {
                // Non-overlapping interval, add it to the merged list
                currentInterval = interval;
                merged.add(currentInterval);
            }
        }
        return merged.toArray(new int[merged.size()][]);
    }

    public static void main(String[] args) {
        int[][] intervals = { { 1, 3 }, { 2, 6 }, { 8, 10 }, { 15, 18 } };
        int[][] mergedIntervals = mergeIntervals(intervals);

        for (int[] interval : mergedIntervals) {
            System.out.println(Arrays.toString(interval));
        }
    }
}