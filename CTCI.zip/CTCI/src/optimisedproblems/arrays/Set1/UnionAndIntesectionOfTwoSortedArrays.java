package optimisedproblems.arrays.Set1;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class UnionAndIntesectionOfTwoSortedArrays {
    /**
     * Method to find union.
     * Most optimised way is :-->
     * @param arr1
     * @param arr2
     * @return List<Integer>
     */
    public static Set<Integer> findUnion(int[] arr1, int[] arr2) {
        Set<Integer> union = new HashSet<>();
        int m= arr1.length;
        int n = arr2.length;
        int minSize = Math.min(m, n);
        for(int i=0; i< minSize; i++) {
            union.add(arr1[i]); 
            union.add(arr2[i]);
        }
        if(m>n) {
            for (int i = n; i < m ; i++) {
                union.add(arr1[i]);
            } 
        }else {
            for (int i = m; i < n ; i++) {
                union.add(arr2[i]);
            } 
        }
        return union;
    }

    /**
     * Use two pointer approach
     * 
     * @param arr1
     * @param arr2
     * @return List<Integer>
     */
    public static List<Integer> findIntersection(int[] arr1, int[] arr2) {
        List<Integer> intersection = new ArrayList<>();
        int i = 0;
        int j = 0;
        while (i < arr1.length && j < arr2.length) {
            if (arr1[i] < arr2[j]) {
                i++;
            } else if (arr1[i] > arr2[j]) {
                j++;
            } else {
                intersection.add(arr1[i]);
                i++;
                j++;
            }
        }

        return intersection;
    }

    public static void main(String[] args) {
        int[] arr1 = { 1, 2, 3, 4, 5 };
        int[] arr2 = { 3, 4, 5, 6, 7,8 };

        Set<Integer> union = findUnion(arr1, arr2);
        System.out.println("Union: " + union);

        List<Integer> intersection = findIntersection(arr1, arr2);
        System.out.println("Intersection: " + intersection);
    }
}