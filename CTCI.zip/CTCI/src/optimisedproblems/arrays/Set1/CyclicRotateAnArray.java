package optimisedproblems.arrays.Set1;

/**
 * Cyclically rotate an array by one place, array is sorted.
 * 
 * @author Anand
 *
 */
public class CyclicRotateAnArray {
    public static void cyclicallyRotate(int[] arr) {
        if (arr.length <= 1) {
            return;
        }
        int temp = arr[arr.length - 1]; 
        for (int i = arr.length - 1; i > 0; i--) {
            arr[i] = arr[i - 1]; // Shift elements one position to the right
        }

        arr[0] = temp; // Place the temporary variable (last element) at the beginning
    }

    public static void main(String[] args) {
        int[] arr = { 1, 2, 3, 4, 5 };
        cyclicallyRotate(arr);

        System.out.println("Cyclically Rotated Array: ");
        for (int num : arr) {
            System.out.print(num + " ");
        }
    }
}
