package optimisedproblems.arrays.Set1;

import java.util.HashMap;
import java.util.Map;

/**
 * 
 * @author Anand 
 * two methods are there 1. sliding window 2. prefix sum both having t.c == O(n).
 *
 */
public class MinimumSubArrayLengthHavingGivenSum {
    // Using window sliding
    public static int findSmallestSubarray(int[] nums, int k) {
        int minLength = Integer.MAX_VALUE;
        // two pointer start and end.
        int start = 0;
        int end = 0;
        int currentSum = 0;
        // iterating end pointer
        while (end < nums.length) {
            // add the value to current sum.
            currentSum += nums[end];
            // if current sum is greater than or equals to k.
            while (currentSum >= k) {
                minLength = Math.min(minLength, end - start + 1);
                currentSum -= nums[start];
                start++;
            }

            end++;
        }

        return (minLength == Integer.MAX_VALUE) ? -1 : minLength;
    }

    /**
     * Using prefix sum. use this.
     * 
     * @param args
     */
    public static int findSmallestSubarrayPrefix(int[] nums, int k) {
        int minLength = Integer.MAX_VALUE;
        int currentSum = 0;
        Map<Integer, Integer> prefixSumMap = new HashMap<>();

        // Add the initial prefix sum of 0 with index -1 to handle cases where the subarray starts from index 0
        prefixSumMap.put(0, -1);

        for (int i = 0; i < nums.length; i++) {
            currentSum += nums[i];
            if (prefixSumMap.containsKey(currentSum - k)) {
                int subarrayLength = i - prefixSumMap.get(currentSum - k);
                minLength = Math.min(minLength, subarrayLength);
            }
            // Store the current prefix sum if it's not already in the map
            if (!prefixSumMap.containsKey(currentSum)) {
                // store the value of i with current sum.
                prefixSumMap.put(currentSum, i);
            }
        }
        return (minLength == Integer.MAX_VALUE) ? -1 : minLength;
    }

    public static void main(String[] args) {
        int[] nums = { 3, 1, 4, 2, 2, 1 };
        int k = 7;
        int smallestSubarrayLength = findSmallestSubarray(nums, k);
        System.out.println("Smallest subarray length with sum " + k + ": " + smallestSubarrayLength);
    }
}