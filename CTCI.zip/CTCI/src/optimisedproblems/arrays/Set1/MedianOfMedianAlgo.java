package optimisedproblems.arrays.Set1;
public class MedianOfMedianAlgo {

    public static int findKthMinimum(int[] array, int k) {
        if (array == null || array.length == 0 || k < 1 || k > array.length) {
            throw new IllegalArgumentException("Invalid input");
        }

        return select(array, 0, array.length - 1, k - 1);
    }

    private static int select(int[] array, int left, int right, int k) {
        if (left == right) {
            return array[left];
        }

        int pivot = getPivot(array, left, right);
        pivot = partition(array, left, right, pivot);

        if (k == pivot) {
            return array[k];
        } else if (k < pivot) {
            return select(array, left, pivot - 1, k);
        } else {
            return select(array, pivot + 1, right, k);
        }
    }

    private static int getPivot(int[] array, int left, int right) {
        if (right - left < 5) {
            return partition5(array, left, right);
        }

        for (int i = left; i <= right; i += 5) {
            int subRight = i + 4;
            if (subRight > right) {
                subRight = right;
            }

            int median5 = partition5(array, i, subRight);
            swap(array, median5, left + (i - left) / 5);
        }

        int mid = (left + right) / 5;
        return select(array, left, left + (right - left) / 5, mid);
    }

    private static int partition5(int[] array, int left, int right) {
        insertionSort(array, left, right);
        return left + (right - left) / 2;
    }

    private static void insertionSort(int[] array, int left, int right) {
        for (int i = left + 1; i <= right; i++) {
            int key = array[i];
            int j = i - 1;
            while (j >= left && array[j] > key) {
                array[j + 1] = array[j];
                j--;
            }
            array[j + 1] = key;
        }
    }

    private static int partition(int[] array, int left, int right, int pivot) {
        int pivotValue = array[pivot];
        swap(array, pivot, right);

        int i = left;
        for (int j = left; j < right; j++) {
            if (array[j] < pivotValue) {
                swap(array, i, j);
                i++;
            }
        }

        swap(array, i, right);
        return i;
    }
    public static void main(String[] args) {
        int[] array = { 9, 2, 8, 1, 5, 4, 3, 7, 6 };
        int k = 3;
        int kthMinimum = findKthMinimum(array, k);
        System.out.println("The " + k + "th minimum value is: " + kthMinimum);
    }
    
    
    
    
    
    private static void swap(int[] array, int i, int j) {
        int temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }
}
