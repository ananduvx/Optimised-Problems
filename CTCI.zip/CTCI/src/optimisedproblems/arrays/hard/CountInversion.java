package optimisedproblems.arrays.hard;

public class CountInversion {
    /**
     * 
     * it is used to determine the number of pair of element in the array that are out of order.
     * 
     * @return
     */
    public static long mergeAndCount(int[] arr, int[] temp, int left, int mid, int right) {
        long count = 0;
        int i = left;
        int j = mid;
        int k = left;

        while (i <= mid - 1 && j <= right) {
            if (arr[i] <= arr[j]) {
                temp[k++] = arr[i++];
            } else {
                temp[k++] = arr[j++];
                count += mid - i;
            }
        }

        while (i <= mid - 1) {
            temp[k++] = arr[i++];
        }

        while (j <= right) {
            temp[k++] = arr[j++];
        }

        for (i = left; i <= right; i++) {
            arr[i] = temp[i];
        }

        return count;
    }

    public static long mergeSortAndCount(int[] arr, int[] temp, int left, int right) {
        long count = 0;
        if (left < right) {
            int mid = (left + right) / 2;

            count += mergeSortAndCount(arr, temp, left, mid);
            count += mergeSortAndCount(arr, temp, mid + 1, right);
            
            count += mergeAndCount(arr, temp, left, mid + 1, right);
        }

        return count;
    }

    public static long countInversions(int[] arr) {
        int n = arr.length;
        int[] temp = new int[n];
        return mergeSortAndCount(arr, temp, 0, n - 1);
    }

    public static void main(String[] args) {
        int[] arr = { 1, 20, 6, 4, 5 };
        long inversions = countInversions(arr);
        System.out.println("Number of inversions: " + inversions);
    }
}
  //Fenwick tree method
// 2nd approach
//public class InversionCount {
//
//    public static int getSum(int[] BIT, int index) {
//        int sum = 0;
//        while (index > 0) {
//            sum += BIT[index];
//            index -= index & (-index);
//        }
//        return sum;
//    }
//
//    public static void updateBIT(int[] BIT, int n, int index, int value) {
//        while (index <= n) {
//            BIT[index] += value;
//            index += index & (-index);
//        }
//    }
//
//    public static long countInversions(int[] arr) {
//        int n = arr.length;
//        int maxElement = 0;
//        for (int i = 0; i < n; i++) {
//            maxElement = Math.max(maxElement, arr[i]);
//        }
//
//        int[] BIT = new int[maxElement + 1];
//        long inversions = 0;
//
//        for (int i = n - 1; i >= 0; i--) {
//            inversions += getSum(BIT, arr[i] - 1);
//            updateBIT(BIT, maxElement, arr[i], 1);
//        }
//
//        return inversions;
//    }
//
//    public static void main(String[] args) {
//        int[] arr = { 5, 3, 2, 4, 1 };
//        long inversions = countInversions(arr);
//        System.out.println("Number of inversions: " + inversions);
//    }
//}