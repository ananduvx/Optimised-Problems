package optimisedproblems.arrays.hard;

import java.util.Random;
    public class KthMinAndMax {
        public static int findKthMin(int[] array, int k) {
            if (array == null || array.length == 0 || k < 1 || k > array.length) {
                throw new IllegalArgumentException("Invalid input or k out of bounds");
            }
            return quickselect(array, 0, array.length - 1, k - 1);
        }

        public static int findKthMax(int[] array, int k) {
            if (array == null || array.length == 0 || k < 1 || k > array.length) {
                throw new IllegalArgumentException("Invalid input or k out of bounds");
            }
            return quickselect(array, 0, array.length - 1, array.length - k);
        }

        private static int quickselect(int[] array, int start, int end, int k) {
            if (start == end) {
                return array[start];
            }
            int pivotIndex = partition(array, start, end);
            if (k == pivotIndex) {
                return array[k];
            } else if (k < pivotIndex) {
                return quickselect(array, start, pivotIndex - 1, k);
            } else {
                return quickselect(array, pivotIndex + 1, end, k);
            }
        }

        private static int partition(int[] array, int start, int end) {
            int pivotIndex = getPivotIndex(start, end);
            int pivot = array[pivotIndex];
            swap(array, pivotIndex, end);
            int i = start;
            for (int j = start; j < end; j++) {
                if (array[j] < pivot) {
                    swap(array, i, j);
                    i++;
                }
            }
            swap(array, i, end);
            return i;
        }

        private static int getPivotIndex(int start, int end) {
            Random rand = new Random();
            return rand.nextInt(end - start + 1) + start;
        }

        private static void swap(int[] array, int i, int j) {
            int temp = array[i];
            array[i] = array[j];
            array[j] = temp;
        }

        public static void main(String[] args) {
            int[] array = {4, 2, 9, 6, 5, 1, 8, 3, 7};
            int k = 3;

            int kthMin = findKthMin(array, k);
            int kthMax = findKthMax(array, k);

            System.out.println("Kth minimum: " + kthMin); // Output: 3
            System.out.println("Kth maximum: " + kthMax); // Output: 7
        }
    }