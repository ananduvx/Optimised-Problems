package optimisedproblems.arrays.hard;

import java.util.HashSet;
import java.util.Set;

public class LongestConsecutiveSubSequence {

    public static int longestConsecutive(int[] nums) {
        Set<Integer> numSet = new HashSet<>();
        int maxLength = 0;
        // Add all elements to the set
        for (int num : nums) {
            numSet.add(num);
        }

        // Find the starting points of sequences
        for (int num : nums) {
            if (!numSet.contains(num - 1)) {
                // Check if num is the starting point of a sequence
                int currentLength = 1;
                while (numSet.contains(num + 1)) {
                    num++;
                    currentLength++;
                }
                maxLength = Math.max(maxLength, currentLength);
            }
        }
        return maxLength;
    }

    public static void main(String[] args) {
        int[] nums = { 100, 4, 200, 1, 3, 2 };
        int longestSeqLength = longestConsecutive(nums);
        System.out.println("Longest consecutive subsequence length: " + longestSeqLength);
    }
}
