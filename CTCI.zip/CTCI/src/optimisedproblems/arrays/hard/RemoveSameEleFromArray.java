package optimisedproblems.arrays.hard;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class RemoveSameEleFromArray {

    public static void removeDup(Integer []arr1,Integer [] arr2) {
            // Convert arrays to lists for easier manipulation
            List<Integer> list1 = new ArrayList<>(Arrays.asList(arr1));
            List<Integer> list2 = new ArrayList<>(Arrays.asList(arr2));

            // Remove common elements from both lists
            list1.removeAll(list2);
            list2.removeAll(Arrays.asList(arr1));

            // Convert lists back to arrays
            arr1 = list1.toArray(new Integer[0]);
            arr2 = list2.toArray(new Integer[0]);

            // Print the updated arrays
            System.out.println("arr1: " + Arrays.toString(arr1));
            System.out.println("arr2: " + Arrays.toString(arr2));
        }

    public static void main(String[] args) {
        // Define the input arrays
        Integer[] arr1 = { 1, 2, 3, 4, 5 };
        Integer[] arr2 = { 3, 4, 5, 6, 7 };
        removeDup(arr1, arr2);

    }

}
