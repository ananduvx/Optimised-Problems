package optimisedproblems.arrays.hard;

/**
 * boyer moore algorithm for majority element. T.C ==O(n), S.C ==O(1).
 * find element which appear max times then check its majority..
 * 
 * @author Anand
 *
 */
public class ElementThatAppearMoreThanNbykTimes {
    public static int findMajorityElement(int[] nums, int k) {
        int n = nums.length;
        int candidate = 0;
        int count = 0;
        // Step 1: Find potential candidates using the Boyer-Moore Voting Algorithm
        //finding candidate by using for loop. 
        for (int i = 0; i < n; i++) {
            // Initially it will have count as 0.
            if (count == 0) {
                candidate = nums[i];
                count = 1;
            } // next time the num[i] will have number.
            else if (nums[i] == candidate) {
                count++;
            } else {
                count--;
            }
        }
        // Step 2: Check if the candidate appears more than n/k times
        count = 0;
        for (int num : nums) {
            if (num == candidate) {
                count++;
            }
        }
        if (count > n / k) {
            return candidate;
        }
        return -1; // No majority element found
    }
    public static void main(String[] args) {
        int[] nums = { 1, 2, 2, 3, 2, 1, 1, 3 };
        int k = 4;
        int majorityElement = findMajorityElement(nums, k);
        if (majorityElement != -1) {
            System.out.println("Majority element: " + majorityElement);
        } else {
            System.out.println("No majority element found");
        }
    }
}
/**
 * Approch-1 one find all the element that is duplicate. put it in a map. then check the value which is equal or more
 * than n/k. return it.
 * 
 * 
 * Approch--2. put all the element in set it will be unique. now compare that element in all the set return which is
 * equal or more than n/k.
 * 
 * Approch -3.
 * 
 * 
 */
