package optimisedproblems.arrays.hard;

/**
 * it means find the next permutation of this number by dictionary order. a[i]<a[i+1] swap then reverse.
 * 
 * @author Anand
 *
 */
public class NextPermutation {
    /**
     * Algo.. 
     * 123654    
     * 1. i = 2  find i from right so that a[i]<a[i+1]
     * 2. 3>4 ? j = 5   find j for which a[i]<a[j]
     * 3. swap i and j  -- 124653
     * 4. reverse from i+1 to n-1 ===>   1, 2, 4, 3, 5, 6
     * 
     * @param nums
     */
    public static void nextPermutation(int[] nums) {
        int n = nums.length; // 3
        int i = n - 2; // 1
        // find the index of the number which is not greater than next from right. here it is 2 which is less than 3 so
        // ind = 1
        while (i >= 0 && nums[i] >= nums[i + 1]) { // 1>0 && 2>= 3? no so --> i remain 1.
            i--;
        }
        if (i >= 0) {
            // Find the smallest element greater than nums[i]
            int j = n - 1;    //2 
            while (j >= 0 && nums[i] >= nums[j]) {    //2>= 3 ?? no so j will be 2
                j--;
            }
            swap(nums, i, j); // i ==1 to j == 2   132 
        }
        reverse(nums, i + 1); // reverse 3 to 3. 
    }

    private static void swap(int[] nums, int i, int j) {
        int temp = nums[i];
        nums[i] = nums[j];
        nums[j] = temp;
    }

    private static void reverse(int[] nums, int start) {
        int end = nums.length - 1;
        while (start < end) {
            swap(nums, start, end);
            start++;
            end--;
        }
    }

    public static void main(String[] args) {
        int[] nums = { 1, 2, 3, 6, 5, 4 };

        nextPermutation(nums);

        // Print the next permutation
        for (int num : nums) {
            System.out.print(num + " ");
        }
    }
}
