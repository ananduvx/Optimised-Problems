package optimisedproblems.arrays.hard;
/**
 * Modified subArray sum.
 * @author Anand
 *
 */
public class MaximumProductSubArraySum {
    public static int maxProduct(int[] nums) {
        int maxProduct = nums[0];
        int currentMax = nums[0];
        //if in-case of negative number. 
        int currentMin = nums[0];

        for (int i = 1; i < nums.length; i++) {
            if (nums[i] < 0) {
                //if get any no. -ve swap current max with min. 
                int temp = currentMax; 
                currentMax = currentMin;
                currentMin = temp;
            }
            currentMax = Math.max(nums[i], currentMax * nums[i]);
            currentMin = Math.min(nums[i], currentMin * nums[i]);
            maxProduct = Math.max(maxProduct, currentMax);
        }
        return maxProduct;
    }
    
    
    /**
     * Using two pointer approch. 
     * @param int
     */
        static int maxProductByTwoPointer(int[] nums) {

          int n = nums.length;
          int leftProduct = 1;
          int rightProduct = 1;
          int ans = nums[0];

          for (int i = 0; i < n; i++) {
            //if any of leftProduct or rightProduct become 0 then update it to 1
            leftProduct = leftProduct == 0 ? 1 : leftProduct;
            rightProduct = rightProduct == 0 ? 1 : rightProduct;
            //prefix product
            leftProduct *= nums[i];
            //suffix product
            rightProduct *= nums[n - 1 - i];
            ans = Math.max(ans, Math.max(leftProduct, rightProduct));
          }
          return ans;
        }

    public static void main(String[] args) {
        int[] nums = { 2, 0, -2, 4 };
        int maxProd = maxProductByTwoPointer(nums);
        System.out.println("Maximum product subarray: " + maxProd);
    }
}