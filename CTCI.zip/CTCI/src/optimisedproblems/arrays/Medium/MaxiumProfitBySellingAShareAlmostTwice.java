package optimisedproblems.arrays.Medium;

/**
 * ab ke hum bichre to sayad kbhi khwao main mile jaise sukhe hue phool kitabon main mile tu khuda hai na mera ishq
 * faristo jaisa dono insaa hai to q itne hizabo main mile.
 * 
 * @author Anand
 *
 */
public class MaxiumProfitBySellingAShareAlmostTwice {
/**
 * T.c = O(n)... S.c= O(1). 
 * @param arr
 * @param size
 * @return int
 */
    static int maxtwobuysell(int arr[], int size) {
        int first_buy = Integer.MIN_VALUE;
        int first_sell = 0;
        int second_buy = Integer.MIN_VALUE;
        int second_sell = 0;
        for (int i = 0; i < size; i++) {
            first_buy = Math.max(first_buy, -arr[i]);
            first_sell = Math.max(first_sell, first_buy + arr[i]);
            second_buy = Math.max(second_buy, first_sell - arr[i]);
            second_sell = Math.max(second_sell, second_buy + arr[i]);
        }
        System.out.println(first_buy);
        System.out.println(first_sell);
        System.out.println(second_buy);
        return second_sell;
    }

    public static void main(String[] args) {
        int arr[] = { 2, 30, 15, 10, 8, 25, 80 };
        int size = arr.length;
        System.out.print(maxtwobuysell(arr, size));
    }
}
