package optimisedproblems.arrays.Medium;

/**
 * Two pointer approach, to make an array pallindrome.
 * 
 * @author Anand
 *
 */
public class MinimumOperationToMakeAnArrayPallindrome {
    public static int minPalindromeOperations(int[] arr) {
        int start = 0;
        int end = arr.length - 1;
        int operations = 0;
        while (start < end) {
            if (arr[start] == arr[end]) {
                start++;
                end--;
            } else if (arr[start] > arr[end]) {
                arr[end - 1] += arr[end];
                end--;
                operations++;
            } else {
                arr[start + 1] += arr[start];
                start++;
                operations++;
            }
        }

        return operations;
    }

    public static void main(String[] args) {
        int[] arr = { 1, 5, 4, 1 };
        int minOperations = minPalindromeOperations(arr);
        System.out.println("Minimum operations required: " + minOperations);
    }
}
