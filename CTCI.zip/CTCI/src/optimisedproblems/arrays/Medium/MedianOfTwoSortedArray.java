package optimisedproblems.arrays.Medium;
/**
 * Use binary search approach.
 * @author Anand
 *
 */
public class MedianOfTwoSortedArray {
    public static double findMedianSortedArrays(int[] arr1, int[] arr2) {
        int n = arr1.length;
        int low = 0;
        int high = n - 1;

        while (low <= high) {
            int mid = (low + high) / 2;
            int otherMid = n - 1 - mid;

            if (arr1[mid] > arr2[otherMid + 1]) {
                high = mid - 1;
            } else if (arr2[mid] > arr1[otherMid + 1]) {
                low = mid + 1;
            } else {
                int maxLeft = Math.max(arr1[mid], arr2[mid]);
                int minRight = Math.min(arr1[mid + 1], arr2[mid + 1]);

                if ((n % 2) == 0) {
                    return (maxLeft + minRight) / 2.0;
                } else {
                    return maxLeft;
                }
            }
        }

        return -1; // Arrays are not sorted or of equal size
    }

    public static void main(String[] args) {
        int[] arr1 = {1, 3, 5};
        int[] arr2 = {2, 4, 6};

        double median = findMedianSortedArrays(arr1, arr2);
        System.out.println("Median: " + median);
    }
}

