package optimisedproblems.arrays.Medium;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;

/**
 * Find some better approach.
 * 
 * @author Anand
 *
 */
public class TripletSumToGivenValue {
    public static boolean findTriplet(int[] array, int targetSum) {
        int n = array.length;
        // Iterate over the array
        for (int i = 0; i < n - 2; i++) {
            HashSet<Integer> set = new HashSet<>();
            int currentSum = targetSum - array[i];
            // Iterate over the remaining elements
            for (int j = i + 1; j < n; j++) {
                int complement = currentSum - array[j];
                // If the complement is found in the set, triplet is found
                if (set.contains(complement)) {
                    System.out.println("Triplet: " + array[i] + ", " + array[j] + ", " + complement);
                    return true;
                }
                // Add the current element to the set
                set.add(array[j]);
            }
        }

        // No triplet found
        return false;
    }

    // To get the triplets by using O(n2).

    public static List<List<Integer>> findTriplets(int[] nums, int target) {
        List<List<Integer>> triplets = new ArrayList<>();
        Arrays.sort(nums);
        for (int i = 0; i < nums.length - 2; i++) {
            if (i == 0 || (i > 0 && nums[i] != nums[i - 1])) {
                int left = i + 1;
                int right = nums.length - 1;
                int currentTarget = target - nums[i];

                while (left < right) {
                    int sum = nums[left] + nums[right];
                    if (sum == currentTarget) {
                        triplets.add(Arrays.asList(nums[i], nums[left], nums[right]));
                        // Skip duplicates
                        while (left < right && nums[left] == nums[left + 1])
                            left++;
                        while (left < right && nums[right] == nums[right - 1])
                            right--;
                        left++;
                        right--;
                    } else if (sum < currentTarget) {
                        left++;
                    } else {
                        right--;
                    }
                }
            }
        }

        return triplets;
    }
    
    public static void main(String[] args) {
        int[] nums = { 1, 2, 2, 3, 4, 5, 6, 7 };
        int targetSum = 16;
        boolean foundTriplet = findTriplet(nums, targetSum);
        if (!foundTriplet) {
            System.out.println("No triplet found");
        }
    }
}