package optimisedproblems.arrays.Medium;

import java.math.BigInteger;

public class FactorialOfLargeNumber {
//iterative method.
    public static BigInteger factorial(int n) {
        BigInteger result = BigInteger.ONE;
        for (int i = 2; i <= n; i++) {
            result = result.multiply(BigInteger.valueOf(i));
        }
        return result;
    }

    public static void main(String[] args) {
        int number = 100; // Example: Factorial of 100
        BigInteger factorial = factorial(number);
        System.out.println(factorial);
    }
}
