package optimisedproblems.arrays.Medium;

public class MinimumSwapAndKTogether {
    public static int minimumSwaps(int[] arr, int k) {
        int countK = 0;
        for (int num : arr) {
            if (num <= k) {
                countK++;
            }
        }
        int countGreater = 0;
        int minSwaps = Integer.MAX_VALUE;

        for (int i = 0; i < arr.length; i++) {
            if (i >= countK) {
                countGreater -= (arr[i - countK] > k) ? 1 : 0;
            }
            if (arr[i] > k) {
                countGreater++;
            }
            if (i >= countK - 1) {
                minSwaps = Math.min(minSwaps, countGreater);
            }
        }
        return minSwaps;
    }

    public static void main(String[] args) {
        int arr1[] = { 2, 7, 9, 5, 8, 7, 4 };
        int k = 5;
        System.out.println(minimumSwaps(arr1, k));
    }
}