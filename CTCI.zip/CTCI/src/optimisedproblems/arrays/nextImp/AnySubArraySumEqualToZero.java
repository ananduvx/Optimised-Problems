package optimisedproblems.arrays.nextImp;

import java.util.HashMap;

public class AnySubArraySumEqualToZero {
    public static boolean hasSubarraySumZero(int[] array) {
        HashMap<Integer, Integer> sumMap = new HashMap<>();
        int currentSum = 0;

        for (int i = 0; i < array.length; i++) {
            currentSum += array[i];
            if (currentSum == 0 || sumMap.containsKey(currentSum)) {
                return true;
            }
            sumMap.put(currentSum, i);
        }
        return false;
    }

    public static void main(String[] args) {
        int[] array = { 4, 2, -3, 1, 6 };
        boolean hasZeroSumSubarray = hasSubarraySumZero(array);
        System.out.println("Has subarray with sum zero: " + hasZeroSumSubarray);
    }
}