package optimisedproblems.arrays.nextImp;

import java.util.HashSet;
import java.util.Set;

public class CountPairWithGivenSum {

    public static int countPairs(int[] arr, int targetSum) {
        int count = 0;
        Set<Integer> set = new HashSet<>();
        for (int num : arr) {
            int complement = targetSum - num;
            if (set.contains(complement)) {
                count++;
            }
            set.add(num);
        }

        return count;
    }

    public static void main(String[] args) {
        int[] arr = {2, 4, 5, 7, 8, 9, 10};
        int targetSum = 12;
        int pairsCount = countPairs(arr, targetSum);
        System.out.println("Number of pairs with sum " + targetSum + ": " + pairsCount);
    }
}