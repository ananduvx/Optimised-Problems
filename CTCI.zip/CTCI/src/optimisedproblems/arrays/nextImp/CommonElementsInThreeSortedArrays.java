package optimisedproblems.arrays.nextImp;

import java.util.ArrayList;
import java.util.List;
/**
 * O(m+n+l)
 * @author Anand
 *
 */
public class CommonElementsInThreeSortedArrays {
    public static List<Integer> findCommonElements(int[] arr1, int[] arr2, int[] arr3) {
        List<Integer> commonElements = new ArrayList<>();

        int n1 = arr1.length, n2 = arr2.length, n3 = arr3.length;
        int i = 0, j = 0, k = 0;

        while (i < n1 && j < n2 && k < n3) {
            if (arr1[i] == arr2[j] && arr2[j] == arr3[k]) {
                commonElements.add(arr1[i]);
                i++;
                j++;
                k++;
            } else if (arr1[i] < arr2[j]) {
                i++;
            } else if (arr2[j] < arr3[k]) {
                j++;
            } else {
                k++;
            }
        }

        return commonElements;
    }

    public static void main(String[] args) {
        int[] arr1 = { 1, 5, 10, 20, 40, 80 };
        int[] arr2 = { 6, 7, 20, 80, 100 };
        int[] arr3 = { 3, 4, 15, 20, 30, 70, 80, 120 };

        List<Integer> commonElements = findCommonElements(arr1, arr2, arr3);

        System.out.println("Common elements: " + commonElements);
    }
}