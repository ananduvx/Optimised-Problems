package optimisedproblems.arrays.nextImp;
/**
 *  T.c O(n)... using only O(1) extra space. 
 * @author Anand
 *
 */
public class RearrangeArrayInPositiveNegativeItems {
    public static void rearrangeAlternating(int[] array) {
        int length = array.length;
        int posPtr = 0;
        int negPtr = 1;
        while (posPtr < length && negPtr < length) {
            // it will return the even number position who have the - ve number. 
            while (posPtr < length && array[posPtr] >= 0) {
                posPtr += 2;
            }
            // Find the next negative number which are at odd place if it is swap it. 
            while (negPtr < length && array[negPtr] <= 0) {
                negPtr += 2;
            }
            // Swap positive and negative numbers
            if (posPtr < length && negPtr < length) {
                //swapping 
                int temp = array[posPtr];
                array[posPtr] = array[negPtr];
                array[negPtr] = temp;
            }
        }
    }
    public static void main(String[] args) {
        int[] array = {1, 2, 3, -4, -1, 4};
        rearrangeAlternating(array);

        // Print the rearranged array
        for (int num : array) {
            System.out.print(num + " ");
        }
    }
}
