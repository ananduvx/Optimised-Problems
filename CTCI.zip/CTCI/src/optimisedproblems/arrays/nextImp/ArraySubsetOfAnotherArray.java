package optimisedproblems.arrays.nextImp;

import java.util.HashSet;

/**
 * yes i have think of the set approach.
 * 
 * @author Anand
 *
 */
public class ArraySubsetOfAnotherArray {
    public static boolean isSubset(int[] array1, int[] array2) {
        // Create a HashSet and add all elements from array1
        HashSet<Integer> set = new HashSet<>();
        for (int num : array1) {
            set.add(num);
        }

        // Check if all elements from array2 are present in the HashSet
        for (int num : array2) {
            if (!set.contains(num)) {
                return false;
            }
        }

        return true;
    }

    public static void main(String[] args) {
        int[] array1 = { 1, 2, 3, 4, 5 };
        int[] array2 = { 3, 4, 5 };

        boolean isSubset = isSubset(array1, array2);

        if (isSubset) {
            System.out.println("array2 is a subset of array1");
        } else {
            System.out.println("array2 is not a subset of array1");
        }
    }
}
