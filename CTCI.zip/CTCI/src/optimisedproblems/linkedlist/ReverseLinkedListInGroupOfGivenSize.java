package optimisedproblems.linkedlist;

import optimisedproblems.linkedlist.ReverseTheLinkedList.Node;

public class ReverseLinkedListInGroupOfGivenSize {
    static ListNode head;
    
   static class ListNode {
        int val;
        ListNode next;

        ListNode(int val) {
            this.val = val;
        }
    }

    public ListNode reverseInGroups(ListNode head, int groupSize) {
        ListNode current = head;
        ListNode previous = null;
        ListNode temp = null;
        int count = 0;

        // Reverse the first group
        while (current != null && count < groupSize) {
            temp = current.next;
            current.next = previous;
            previous = current;
            current = temp;
            count++;
        }

        // Recursively reverse remaining groups
        if (temp != null) {
            head.next = reverseInGroups(temp, groupSize);
        }

        return previous;
    }
    
    void printList(ListNode head2) {
        while (head2 != null) {
            System.out.print(head2.val + " ");
            head2 = head2.next;
        }
    }

    public static void main(String[] args) {
        ReverseLinkedListInGroupOfGivenSize list = new ReverseLinkedListInGroupOfGivenSize();
        list.head = new ListNode(85);
        list.head.next = new ListNode(15);
        list.head.next.next = new ListNode(4);
        list.head.next.next.next = new ListNode(20);

        System.out.println("Given linked list");
        list.printList(list.head);
        list.head = list.reverseInGroups(list.head,2);
        System.out.println("");
        System.out.println("Reversed linked list ");
        list.printList(head);
    }
}
