package optimisedproblems.linkedlist;

public class AddOneToNumberRepresentedAsLinkedList {

    public static Node addOne(Node head) {
        Node dummy = new Node(0); // Create a dummy node
        dummy.next = head;
        Node lastNonNine = dummy;
        Node current = head;

        // Find the rightmost non-nine digit
        while (current != null) {
            if (current.data != 9) {
                lastNonNine = current;
            }
            current = current.next;
        }

        // Increment the rightmost non-nine digit and propagate the carry
        lastNonNine.data++;
        current = lastNonNine.next;
        while (current != null) {
            current.data = 0;
            current = current.next;
        }

        // If the dummy node is the first node, remove it
        if (dummy.data == 0) {
            return dummy.next;
        }

        return dummy;
    }

    public static void display(Node head) {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }

    public static void main(String[] args) {
        Node head = new Node(9);
        head.next = new Node(9);
        head.next.next = new Node(9);

        System.out.println("Original Linked List:");
        display(head);

        System.out.println("Linked List after adding 1:");
        head = addOne(head);
        display(head);
    }
}