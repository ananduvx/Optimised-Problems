package optimisedproblems.linkedlist;

//Both iterative and recursive...
public class ReverseTheLinkedList {
    static Node head;

    static class Node {
        int data;
        Node next;

        Node(int d) {
            data = d;
            next = null;
        }
    }
    Node reverse(Node node) {
        Node prev = null;
        Node current = node;
        Node temp = null;
        while (current != null) {
            //storing the current next.
            temp = current.next;
            //1st pointer next should be null
            current.next = prev;
            // assigning the prev as current.
            prev = current;
            // assigning the current as temp one as link got break. 
            current = temp;
        }
        node = prev;
        return node;
    }

    void printList(Node node) {
        while (node != null) {
            System.out.print(node.data + " ");
            node = node.next;
        }
    }

    static Node reverseRecusrsive(Node head) {
        if (head == null || head.next == null)
            return head;

        /*
         * reverse the rest list and put the first element at the end
         */
        Node rest = reverseRecusrsive(head.next);
        //above one will reverse all but leave the first one. 
        head.next.next = head;
        //setting head.next as null. 
        head.next = null;

        /* fix the head pointer */
        return rest;
    }

    public static void main(String[] args) {
        ReverseTheLinkedList list = new ReverseTheLinkedList();
        list.head = new Node(85);
        list.head.next = new Node(15);
        list.head.next.next = new Node(4);
        list.head.next.next.next = new Node(20);

        System.out.println("Given linked list");
        list.printList(head);
        head = list.reverse(head);
        System.out.println("");
        System.out.println("Reversed linked list ");
        list.printList(head);
    }
}