package optimisedproblems.linkedlist;

import java.util.HashSet;

class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}

public class RemoveDuplicateFromUnsortedLinkedList {
//Using Two pointer Approach  T.c -= O(n),, S.c --O(1). 
    public static void removeDuplicates(Node head) {
        if (head == null)
            return;
        Node current = head;
        while (current != null) {
            Node runner = current;
            while (runner.next != null) {
                if (runner.next.data == current.data) {
                    runner.next = runner.next.next;
                } else {
                    runner = runner.next;
                }
            }
            current = current.next;
        }
    }
  //Using hashSet to remove duplicates
    public static void removeDuplicatesUsingHashSet(Node head) {
        if (head == null)
            return;  
        Node current = head;
        Node prev = null;
        HashSet<Integer> uniqueElements = new HashSet<>();
        while (current != null) {
            int currentData = current.data;
            if (uniqueElements.contains(currentData)) {
                prev.next = current.next;
            } else {
                uniqueElements.add(currentData);
                prev = current;
            }
            current = current.next;
        }
    }
    public static void display(Node head) {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }

    public static void main(String[] args) {
        Node head = new Node(10);
        head.next = new Node(20);
        head.next.next = new Node(30);
        head.next.next.next = new Node(20);
        head.next.next.next.next = new Node(40);
        head.next.next.next.next.next = new Node(10);

        System.out.println("Original Linked List:");
        display(head);

        System.out.println("Linked List after removing duplicates:");
        removeDuplicates(head);
        display(head);
    }
}


