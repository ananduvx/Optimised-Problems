package optimisedproblems.linkedlist;

class ListNode {
    int val;
    ListNode next;
    
    ListNode(int val) {
        this.val = val;
    }
}
public class AddTwoNumberRepresentedByLinkedList {
    public static ListNode addTwoNumbers(ListNode l1, ListNode l2) {
        ListNode dummyHead = new ListNode(0); // Dummy node to hold the result
        ListNode curr = dummyHead; // Current node
        int carry = 0; // Carry value

        while (l1 != null || l2 != null || carry != 0) {
            int sum = carry;

            if (l1 != null) {
                sum += l1.val;
                l1 = l1.next;
            }

            if (l2 != null) {
                sum += l2.val;
                l2 = l2.next;
            }

            curr.next = new ListNode(sum % 10); // Create a new node with the sum mod 10
            carry = sum / 10; // Calculate the carry
            curr = curr.next;
        }

        return dummyHead.next; // Return the result list without the dummy head
    }

    public static void main(String[] args) {
        // Creating the first linked list: 2 -> 4 -> 3
        ListNode l1 = new ListNode(2);
        l1.next = new ListNode(4);
        l1.next.next = new ListNode(3);

        // Creating the second linked list: 5 -> 6 -> 4
        ListNode l2 = new ListNode(5);
        l2.next = new ListNode(6);
        l2.next.next = new ListNode(4);

        ListNode sum = addTwoNumbers(l1, l2);

        // Printing the sum: 7 -> 0 -> 8
        while (sum != null) {
            System.out.print(sum.val + " ");
            sum = sum.next;
        }
    }
}