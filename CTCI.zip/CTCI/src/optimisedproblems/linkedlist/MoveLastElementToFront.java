package optimisedproblems.linkedlist;

public class MoveLastElementToFront {
    static class Node {
        int data;
        Node next;

        public Node(int data) {
            this.data = data;
            this.next = null;
        }
    }

    public static Node moveLastToFront(Node head) {
        if (head == null || head.next == null)
            return head;
        Node last = head;
        Node prev = null;
        //it will iterate the whole list. 
        while (last.next != null) {
            prev = last;
            last = last.next;
        }
        prev.next = null; // Disconnect the last node from the list
        last.next = head; // Move last node to the front
        head = last; // Update the new head

        return head;
    }

    public static void display(Node head) {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }

    public static void main(String[] args) {
        Node head = new Node(10);
        head.next = new Node(20);
        head.next.next = new Node(30);
        head.next.next.next = new Node(40);
        head.next.next.next.next = new Node(50);

        System.out.println("Original Linked List:");
        display(head);

        System.out.println("Linked List after moving last element to front:");
        head = moveLastToFront(head);
        display(head);
    }
}