package optimisedproblems.linkedlist.loopingProblems;

/**
 * Floyd’s Cycle detection algorithm using two pointer basically.
 * 
 * @author Anand
 *
 */
class Node {
    int data;
    Node next;

    Node(int data) {
        this.data = data;
        this.next = null;
    }
}

public class DeleteLoopInLinkedList {
    Node head;

    void detectAndRemoveLoop() {
        if (head == null || head.next == null) {
            return; // No loop
        }

        Node slow = head;
        Node fast = head;
        boolean loopExists = false;

        while (fast != null && fast.next != null) {
            slow = slow.next;
            fast = fast.next.next;

            if (slow == fast) {
                loopExists = true;
                break;
            }
        }

        if (loopExists) {
            // Move slow to the head and advance both pointers at the same pace until they meet again
            slow = head;

            while (slow.next != fast.next) {
                slow = slow.next;
                fast = fast.next;
            }
            // Found the start of the loop, so remove it
            fast.next = null;
        }
    }

    public static void main(String[] args) {
        DeleteLoopInLinkedList list = new DeleteLoopInLinkedList();
        // Create a linked list with a loop
        list.head = new Node(1);
        Node node2 = new Node(2);
        Node node3 = new Node(3);
        Node node4 = new Node(4);
        Node node5 = new Node(5);

        list.head.next = node2;
        node2.next = node3;
        node3.next = node4;
        node4.next = node5;
        node5.next = node2; // Creating a loop

        System.out.println("Original Linked List:");
//        list.printLinkedList();

        list.detectAndRemoveLoop();

        System.out.println("Linked List after removing the loop:");
        list.printLinkedList();
    }

    void printLinkedList() {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }

}