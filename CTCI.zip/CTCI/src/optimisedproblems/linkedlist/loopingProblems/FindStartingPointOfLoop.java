package optimisedproblems.linkedlist.loopingProblems;

class ListNode {
    int val;
    ListNode next;

    ListNode(int val) {
        this.val = val;
        this.next = null;
    }
}

public class FindStartingPointOfLoop {
    
    public ListNode detectCycle(ListNode head) {
        if (head == null || head.next == null) {
            return null; // No loop if the linked list is empty or has only one node
        }

        ListNode slow = head;
        ListNode fast = head;

        while (fast != null && fast.next != null) {
            slow = slow.next;
            fast = fast.next.next;
            if (slow == fast) { // Loop detected
                slow = head;
                while (slow != fast) {
                    slow = slow.next;
                    fast = fast.next;
                }
                return slow; // Return the first node of the loop
            }
        }

        return null; // No loop found
    }

    public static void main(String[] args) {
        FindStartingPointOfLoop list = new FindStartingPointOfLoop();

        // Create a linked list with a loop (for demonstration purposes)
        ListNode head = new ListNode(1);
        head.next = new ListNode(2);
        head.next.next = new ListNode(3);
        head.next.next.next = new ListNode(4);
        head.next.next.next.next = new ListNode(5);
        head.next.next.next.next.next = head.next; // Create a loop

        ListNode loopStart = list.detectCycle(head);
        if (loopStart != null) {
            System.out.println("Loop found. The first node of the loop is: " + loopStart.val);
        } else {
            System.out.println("No loop found in the linked list.");
        }
    }
}