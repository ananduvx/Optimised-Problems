package optimisedproblems.Greedy;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

class Job implements Comparable<Job> {
        char id;
        int deadline, profit;

        public Job(char id, int deadline, int profit) {
            this.id = id;
            this.deadline = deadline;
            this.profit = profit;
        }

        @Override
        public int compareTo(Job other) {
            // Sort jobs in descending order of profits
            return other.profit - this.profit;
        }
    }

    public class JobSequencingProblem {
        public static void scheduleJobs(List<Job> jobs) {
            // Sort jobs based on profits (in descending order)
            Collections.sort(jobs);

            int maxDeadline = getMaxDeadline(jobs);
            char[] sequence = new char[maxDeadline];
            boolean[] slotOccupied = new boolean[maxDeadline];

            // Fill the slots with the most profitable jobs
            for (Job job : jobs) {
                for (int i = Math.min(maxDeadline - 1, job.deadline - 1); i >= 0; i--) {
                    if (!slotOccupied[i]) {
                        sequence[i] = job.id;
                        slotOccupied[i] = true;
                        break;
                    }
                }
            }

            // Print the scheduled job sequence
            System.out.println("Job sequence:");
            for (char job : sequence) {
                System.out.print(job + " ");
            }
        }

        private static int getMaxDeadline(List<Job> jobs) {
            int maxDeadline = Integer.MIN_VALUE;
            for (Job job : jobs) {
                maxDeadline = Math.max(maxDeadline, job.deadline);
            }
            return maxDeadline;
        }

        public static void main(String[] args) {
            List<Job> jobs = new ArrayList<>();
            jobs.add(new Job('A', 2, 100));
            jobs.add(new Job('B', 1, 19));
            jobs.add(new Job('C', 2, 27));
            jobs.add(new Job('D', 1, 25));
            jobs.add(new Job('E', 3, 15));

            scheduleJobs(jobs);
        }
    }
