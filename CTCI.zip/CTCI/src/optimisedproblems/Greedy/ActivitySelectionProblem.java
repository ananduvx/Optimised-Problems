package optimisedproblems.Greedy;
/**
 * T.c O(nlogn)
 */
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

class Activity {
    int start;
    int end;

    public Activity(int start, int end) {
        this.start = start;
        this.end = end;
    }
}
/**
 * or maximum Disjoint intervals 
 * 
 * @author Anand
 *
 */
public class ActivitySelectionProblem {
    public static List<Activity> selectActivities(List<Activity> activities) {
        List<Activity> selectedActivities = new ArrayList<>();

        // Sort activities by their start time
        Collections.sort(activities, Comparator.comparingInt(a -> a.start));

        Activity previousActivity = activities.get(0);
        selectedActivities.add(previousActivity);

        for (int i = 1; i < activities.size(); i++) {
            Activity currentActivity = activities.get(i);

            // Select the activity if it doesn't overlap with the previous one
            if (currentActivity.start >= previousActivity.end) {
                selectedActivities.add(currentActivity);
                previousActivity = currentActivity;
            }
        }

        return selectedActivities;
    }

    public static void main(String[] args) {
        List<Activity> activities = new ArrayList<>();
        activities.add(new Activity(1, 4));
        activities.add(new Activity(3, 5));
        activities.add(new Activity(0, 6));
        activities.add(new Activity(5, 7));
        activities.add(new Activity(3, 8));
        activities.add(new Activity(5, 9));
        activities.add(new Activity(6, 10));
        activities.add(new Activity(8, 11));
        activities.add(new Activity(8, 12));
        activities.add(new Activity(2, 13));
        activities.add(new Activity(12, 14));

        List<Activity> selectedActivities = selectActivities(activities);

        System.out.println("Selected activities:");
        for (Activity activity : selectedActivities) {
            System.out.println("[" + activity.start + ", " + activity.end + "]");
        }
    }
}