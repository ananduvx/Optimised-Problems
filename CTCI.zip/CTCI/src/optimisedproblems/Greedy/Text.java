package optimisedproblems.Greedy;

public class Text {
/**
 * Followings are the greedy algo.
 * Kruskal’s Minimum Spanning Tree (MST): 
 * Prim’s Minimum Spanning Tree: 
 * Dijkstra’s Shortest Path: 
 * Huffman Coding: 
 */
}
