package optimisedproblems.searchingAndSorting;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
/**
 *
 * @author Anand
 *
 */
public class SubArrayWithZeroSum {
    
    public static void printZeroSumSubarrays(int[] arr) {
        Map<Integer, List<Integer>> map = new HashMap<>();
        List<Pair> subarrays = new ArrayList<>();
        int sum = 0;

        for (int i = 0; i < arr.length; i++) {
            sum += arr[i];
            if (sum == 0) {
                subarrays.add(new Pair(0, i));
            }
            if (map.containsKey(sum)) {
                List<Integer> indices = map.get(sum);
                for (Integer index : indices) {
                    subarrays.add(new Pair(index + 1, i));
                }
            }
            if (!map.containsKey(sum)) {
                map.put(sum, new ArrayList<>());
            }
            map.get(sum).add(i);
        }

        for (Pair pair : subarrays) {
            System.out.println("Subarray found from index " + pair.start + " to " + pair.end);
        }
    }

    static class Pair {
        int start;
        int end;

        public Pair(int start, int end) {
            this.start = start;
            this.end = end;
        }
    }

    public static void main(String[] args) {
        int[] arr = { 4, 2, -3, -1, 0, 4 };
        printZeroSumSubarrays(arr);
    }
}