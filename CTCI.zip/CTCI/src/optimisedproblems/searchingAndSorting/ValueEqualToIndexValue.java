package optimisedproblems.searchingAndSorting;

/**
 * Linear search O(n). Aux Space -O(1)
 * what if elements will be duplicate 
 * @author Anand
 *
 */
public class ValueEqualToIndexValue {

}
