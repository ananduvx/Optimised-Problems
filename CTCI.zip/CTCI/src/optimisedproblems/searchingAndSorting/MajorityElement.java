package optimisedproblems.searchingAndSorting;

import java.util.Arrays;

/**
 * find the majority element with T.c- O(nlogn).. S.c =O(1). find by sorting.
 * 
 * @author Anand
 *
 */
public class MajorityElement {
    public static int majorityElement(int[] arr, int n) {

        // Sort the array in O(nlogn)
        Arrays.sort(arr);
        int count = 1, temp = arr[0];
        for (int i = 1; i < n; i++) {
            // Increases the count if the same element occurs otherwise starts counting new element
            if (temp == arr[i]) {
                count++;
            } else {
                count = 1;
                temp = arr[i];
            }
            if(count>n/2) {
                return arr[i];
            }
        }
        // Returns maximum occurred element if there is no such element, returns -1
        return -1;
    }
    public static void main(String[] args) {
        int arr[] = { 1, 2, 2, 2, 3, 5, 2 };
        int n = 7;

        System.out.println(majorityElement(arr, n));
    }
}
