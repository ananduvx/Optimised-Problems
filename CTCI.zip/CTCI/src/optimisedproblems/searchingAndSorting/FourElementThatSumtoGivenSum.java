package optimisedproblems.searchingAndSorting;

import java.util.HashMap;
import java.util.Map;

public class FourElementThatSumtoGivenSum {
        public static int[] findFourElementsWithSum(int[] nums, int target) {
            Map<Integer, int[]> map = new HashMap<>();
            int n = nums.length;
            // Store all pairs and their sums in a HashMap
            for (int i = 0; i < n - 1; i++) {
                for (int j = i + 1; j < n; j++) {
                    int sum = nums[i] + nums[j];
                    map.put(sum, new int[]{i, j});
                }
            }
            // Find two pairs with the desired sum
            for (int i = 0; i < n - 1; i++) {
                for (int j = i + 1; j < n; j++) {
                    int remainingSum = target - (nums[i] + nums[j]);
                    if (map.containsKey(remainingSum)) {
                        int[] pair = map.get(remainingSum);
                        if (pair[0] != i && pair[1] != i && pair[0] != j && pair[1] != j) {
                            return new int[]{nums[i], nums[j], nums[pair[0]], nums[pair[1]]};
                        }
                    }
                }
            }
            return null; // If no such four elements are found
        }
        public static void main(String[] args) {
            int[] nums = {1, 2, 3, 4, 5, 6, 7, 8, 9};
            int target = 20;

            int[] result = findFourElementsWithSum(nums, target);
            if (result != null) {
                System.out.println("Four elements found:");
                for (int num : result) {
                    System.out.print(num + " ");
                }
            } else {
                System.out.println("No four elements found with the given sum.");
            }
        }
    }
