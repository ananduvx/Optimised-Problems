package optimisedproblems.searchingAndSorting;

/**
 * Pairwise comparision with unrolling
 * 
 * @author Anand
 *
 */
public class MinimaAndMaximaHavingLessComparision {
    static class MinMax {
        int min;
        int max;
    }

    static MinMax findMinMax(int[] array) {
        MinMax result = new MinMax();
        int n = array.length;
        // If the array is empty
        if (n == 0) {
            return result;
        }
        // If there is only one element in the array
        if (n == 1) {
            result.min = array[0];
            result.max = array[0];
            return result;
        }
        int i;
        // Initialize the minimum and maximum values
        if (array[0] < array[1]) {
            result.min = array[0];
            result.max = array[1];
        } else {
            result.min = array[1];
            result.max = array[0];
        }
        // Compare elements in pairs with unrolling
        for (i = 2; i < n - 1; i += 2) {
            if (array[i] < array[i + 1]) {
                if (array[i] < result.min) {
                    result.min = array[i];
                }
                if (array[i + 1] > result.max) {
                    result.max = array[i + 1];
                }
            } else {
                if (array[i + 1] < result.min) {
                    result.min = array[i + 1];
                }
                if (array[i] > result.max) {
                    result.max = array[i];
                }
            }
        }

        // Handle the case where the array length is odd
        if (i == n - 1) {
            if (array[i] < result.min) {
                result.min = array[i];
            } else if (array[i] > result.max) {
                result.max = array[i];
            }
        }

        return result;
    }

    public static void main(String[] args) {
        int[] array = { 5, 3, 9, 2, 6, 1 };
        MinMax result = findMinMax(array);
        System.out.println("Minimum value: " + result.min);
        System.out.println("Maximum value: " + result.max);
    }
}