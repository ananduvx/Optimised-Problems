package optimisedproblems.searchingAndSorting;

public class OptimumLocationOfAPointToMinimizeTotalDistance {
        public static Point calculateCentroid(Point[] points) {
            double sumX = 0.0;
            double sumY = 0.0;

            for (Point point : points) {
                sumX += point.x;
                sumY += point.y;
            }

            int numPoints = points.length;
            double centroidX = sumX / numPoints;
            double centroidY = sumY / numPoints;

            return new Point(centroidX, centroidY);
        }

        public static void main(String[] args) {
            Point[] points = {
                new Point(1, 3),
                new Point(2, 5),
                new Point(4, 2),
                new Point(6, 4)
            };

            Point centroid = calculateCentroid(points);
            System.out.println("Centroid coordinates: (" + centroid.x + ", " + centroid.y + ")");
        }
    }

    class Point {
        double x;
        double y;

        public Point(double x, double y) {
            this.x = x;
            this.y = y;
        }
    }
