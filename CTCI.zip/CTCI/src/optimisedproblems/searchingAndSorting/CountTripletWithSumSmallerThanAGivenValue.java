package optimisedproblems.searchingAndSorting;

import java.util.Arrays;

/**
 * 
 * @author Anand
 *
 */
public class CountTripletWithSumSmallerThanAGivenValue {
public int countTriplets(int[] arr, int targetSum) {
    if (arr == null || arr.length < 3) {
        return 0;
    }

    Arrays.sort(arr);
    int count = 0;
    int n = arr.length;

    for (int i = 0; i < n - 2; i++) {
        int left = i + 1;
        int right = n - 1;

        while (left < right) {
            int currentSum = arr[i] + arr[left] + arr[right];
            if (currentSum >= targetSum) {
                right--;
            } else {
                count += (right - left);
                left++;
            }
        }
    }

    return count;
}
}