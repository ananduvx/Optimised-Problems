package optimisedproblems.searchingAndSorting;

/**
 * Using merge sort. O(nlogn)
 * 
 * @author Anand
 *
 */
public class MergeTwoSortedArray {

    public int[] mergeSortedArrays(int[] arr1, int[] arr2) {
        int n1 = arr1.length;
        int n2 = arr2.length;
        int[] merged = new int[n1 + n2];
        int i = 0, j = 0, k = 0;
        while (i < n1 && j < n2) {
            if (arr1[i] <= arr2[j]) {
                merged[k] = arr1[i];
                i++;
            } else {
                merged[k] = arr2[j];
                j++;
            }
            k++;
        }
        // Copy the remaining elements from arr1, if any
        while (i < n1) {
            merged[k] = arr1[i];
            i++;
            k++;
        }
        // Copy the remaining elements from arr2, if any
        while (j < n2) {
            merged[k] = arr2[j];
            j++;
            k++;
        }
        return merged;
    }
}
