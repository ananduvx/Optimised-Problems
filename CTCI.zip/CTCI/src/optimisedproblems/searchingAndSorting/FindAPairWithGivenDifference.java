package optimisedproblems.searchingAndSorting;
import java.util.Arrays;
import java.util.HashSet;
/**
 * Binary search algo T.c--O(log n)
 * we can solve it at O(n) using hashmap
 * @author Anand
 *
 */
public class FindAPairWithGivenDifference {
    public static int[] findPairWithGivenDifference(int[] arr, int targetDiff) {
        HashSet<Integer> set = new HashSet<>();
        for (int num : arr) {
//            5-78 , 20-78 ,3-78,2-78,50-78,80-78
            int complement = num - targetDiff;           
            if (set.contains(complement)) {              
                return new int[]{complement, num};
            }                                           
//          set has 5,20,3,2,50,80
            set.add(num);                               
        }
        return null; // If no pair is found
    }
    /**
     * using two pointer O(nLogn) which is >O(n).
     * 
     * @param args
     */
    public static int[] findPair(int[] arr, int targetDiff) {
        Arrays.sort(arr); // Sort the array in ascending order O(logn)
        int left = 0;
        int right = 1;

        while (right < arr.length) {
            int diff = arr[right] - arr[left];
            if (diff == targetDiff) {
                return new int[]{arr[left], arr[right]};
            } else if (diff < targetDiff) {
                right++;
            } else {
                left++;
                // Make sure left and right pointers are not at the same element
                if (left == right) {
                    right++;
                }
            }
        }
        return null; // If no pair is found
    }
    public static void main(String[] args) {
        int[] array = {5, 20, 3, 2, 50, 80};
        int difference = 78;
        int[] pair = findPairWithGivenDifference(array, difference);
        if (pair != null) {
            System.out.println("Pair found: " + pair[0] + ", " + pair[1]);
        } else {
            System.out.println("No pair found with the given difference.");
        }
    }
}

























