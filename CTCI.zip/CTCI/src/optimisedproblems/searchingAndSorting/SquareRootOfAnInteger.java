package optimisedproblems.searchingAndSorting;

/**
 * Count square using memoization n dynamic programming.
 * 
 * @author Anand
 *
 */
public class SquareRootOfAnInteger {
        public int countPerfectSquares(int n) {
            int count = 0;
            
            for (int i = 1; i < n; i++) {
                if (isPerfectSquare(i)) {
                    count++;
                }
            }
            
            return count;
        }
        
        public boolean isPerfectSquare(int num) {
            int sqrt = (int) Math.sqrt(num);
            return sqrt * sqrt == num;
        }
        
        public static void main(String[] args) {
            int n = 3;
            
            SquareRootOfAnInteger ps = new SquareRootOfAnInteger();
            int count = ps.countPerfectSquares(n);
            System.out.println("Number of perfect squares from 1 to " + n + ": " + count);
        }
    }
