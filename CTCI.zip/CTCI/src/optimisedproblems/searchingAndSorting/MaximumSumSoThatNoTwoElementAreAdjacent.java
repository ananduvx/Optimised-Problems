package optimisedproblems.searchingAndSorting;

/**
 * //Java program to find the maximum stolen value Stickler Thief
 * 
 * @author Anand
 *
 */
public class MaximumSumSoThatNoTwoElementAreAdjacent {

    public static int findMaxSum(int[] arr) {
        if (arr == null || arr.length == 0) {
            return 0;
        }
        int prevSum = 0;
        int currSum = 0;

       for (int i = 0; i < arr.length; i++) {
            int temp = currSum;
            currSum = Math.max(prevSum + arr[i], currSum);
            prevSum = temp;
        }
        return currSum;
    }

    public static void main(String[] args) {
        int hval[] = {5, 3, 4, 11, 2};
        System.out.println("Maximum loot possible : " + findMaxSum(hval));
    }
}
