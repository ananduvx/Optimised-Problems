package optimisedproblems.binarytree;

public class SortedToBSt {
    public static boolean solution(int[] numbers, int nrToFind) {
        return new Node(numbers).find(nrToFind);
    }
    public static void main(String args[]) {
        int[] A = { 1, 2, 3, 4, 5, 6 };
        System.out.println(solution(A, 7));
    }
}
/**
 * Class to create bst and then find if element is there or not. 
 * @author Anand
 *
 */
class Node {
    public Integer value;
    public Node left;
    public Node right;

    public Node(int value) {
        this.value = value;
        this.left = null;
        this.right = null;
    }

    public Node(int[] numbers) {
        // Construct the binary tree from the array
        this.value = numbers[numbers.length / 2];
        this.left = constructTree(numbers, 0, numbers.length / 2 - 1);
        this.right = constructTree(numbers, numbers.length / 2 + 1, numbers.length - 1);
    }

    private Node constructTree(int[] numbers, int start, int end) {
        if (start > end) {
            return null;
        }

        int mid = start + (end - start) / 2;
        Node node = new Node(numbers[mid]);
        node.left = constructTree(numbers, start, mid - 1);
        node.right = constructTree(numbers, mid + 1, end);

        return node;
    }

    public boolean find(int nrToFind) {
        return search(this, nrToFind);
    }

    private boolean search(Node root, int nrToFind) {
        if (root == null) {
            return false;
        }

        if (root.value == nrToFind) {
            return true;
        } else if (root.value > nrToFind) {
            return search(root.left, nrToFind);
        } else {
            return search(root.right, nrToFind);
        }
    }
}
