package optimisedproblems.interview;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MaxDigitOccurrences {
    public static void main(String[] args) {
        List<Integer> numbers = Arrays.asList(23, 29, 31, 37, 39);
        Map<Integer, Integer> digitCountMap = new HashMap<>();

        for (int number : numbers) {
            while (number > 0) {
                int digit = number % 10;
                digitCountMap.put(digit, digitCountMap.getOrDefault(digit, 0) + 1);
                number /= 10;
            }
        }

        int maxOccurrences = Collections.max(digitCountMap.values());

        List<Integer> mostFrequentDigits = new ArrayList<>();
        for (Map.Entry<Integer, Integer> entry : digitCountMap.entrySet()) {
            if (entry.getValue() == maxOccurrences) {
                mostFrequentDigits.add(entry.getKey());
            }
        }

        System.out.println("Maximum occurrences of a digit: " + maxOccurrences);
        System.out.println("Most frequent digit(s): " + mostFrequentDigits);
    }
}