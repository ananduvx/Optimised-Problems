package optimisedproblems.interview;
/**
 * Method to count and print the char. 
 * O(n)
 * @author Anand
 *
 */
public class FindConsecutiveRepeats {

    private static StringBuilder twiceRepeating(String input) {
        StringBuilder result = new StringBuilder();
        int n = input.length();
        int i = 0;
        while (i < n) {
            char currentChar = input.charAt(i);
            int count = 0;
            //count the char. 
            while (i < n && input.charAt(i) == currentChar) {
                count++;
                i++;
            }
            if (count == 2) {
                result.append(currentChar);
            }
        }
        return result;
    }
    
        public static void main(String[] args) {
            String input = "abaccchhaaxyy";
            System.out.println(twiceRepeating(input).toString());
        }
    }
