package optimisedproblems.interview;



import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
public class StramQues {
    public static void main(String args[]) {   
//    List <Employee> listEmployee = new ArrayList<>();
//    
//    listEmployee.add( new Employee("Anand","Prakash",26));
//    listEmployee.add( new Employee("Anand","kumar",27));
    
    /**
     * Sorting based on the name and then age. 
     */
//    listEmployee.stream()
//    .sorted(Comparator.comparing(Employee ::getFirstName)
//    .thenComparingInt(Employee::getAge))
//    .collect(Collectors.toList());
//    
//    for(Employee  e: listEmployee) {
//        System.out.println(e.getFirstName());
//    }
    
    /**
     * Finding sum of element. 
     */
    List<Integer> array = Arrays.asList(-2, 0, 4, 6, 8);
    int sum = array.stream().reduce(0,
            (e1, e2) -> e1 + e2);
    System.out.println(sum);
    
    /**
     * Using Map to multiply each number with 3. 
     */
    array.stream().map(number -> number * 3).forEach(System.out::println);
    
    
    
    }   
    
      
}