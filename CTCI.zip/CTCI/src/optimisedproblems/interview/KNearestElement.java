package optimisedproblems.interview;

import java.util.ArrayList;
import java.util.List;

/**
 * This Questions asked in Altimetrik 
 * find the k nearest element. 
 * @author Anand
 *
 */
public class KNearestElement {
    public List<Integer> findKNearest(int[] arr, int k, int x) {
        List<Integer> result = new ArrayList<>();
        // Perform binary search to find the index of the closest element to X.
        int left = 0;
        int right = arr.length - 1;
        while (right - left >= k) {
            int leftDist = Math.abs(arr[left] - x); // 2 -19 = 17
            int rightDist = Math.abs(arr[right] - x); // 32- 19 = 13

            if (leftDist > rightDist) {
                left++;
            } else {
                right--;
            }
        }

        // Collect the K nearest elements.
        for (int i = left; i <= right + 1; i++) {
            if (arr[i] != x) {
                result.add(arr[i]);
            }
        }

        return result;
    }

    public static void main(String[] args) {
        KNearestElement finder = new KNearestElement();
        int[] arr = { 2, 5, 8, 10, 13, 17, 19, 25, 27, 32 };
        int k = 4;
        int x = 19;
        List<Integer> nearestElements = finder.findKNearest(arr, k, x);

        System.out.println("K Nearest Elements to " + x + ": " + nearestElements);
    }
}
