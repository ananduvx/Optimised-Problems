package optimisedproblems.interview;

import java.util.HashMap;
import java.util.Map;

public class MaxReaeatingCount {
    public static int findMaxRepeatingCharacters(String str) {
        Map<Character, Integer> countMap = new HashMap<>();

        for (char c : str.toCharArray()) {
            countMap.put(c, countMap.getOrDefault(c, 0) + 1);
        }
        int maxRepeatingCount = 0;
        for (int count : countMap.values()) {
            if (count > maxRepeatingCount) {
                maxRepeatingCount = count;
            }
        }
        return maxRepeatingCount;
    }

    public static void main(String[] args) {
        String str = "aabbbbccddddd";
        int maxRepeatingCount = findMaxRepeatingCharacters(str);
        System.out.println("Maximum repeating count: " + maxRepeatingCount);
    }
}
