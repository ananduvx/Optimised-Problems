package optimisedproblems.interview;

import java.util.ArrayDeque;
import java.util.Deque;

/**
 * Next largest ele and element greater to right.
 * 
 * @author Anand
 *
 */
public class NextGreaterElementInAllArray {
    public static int[] findNextGreaterElements(int[] arr) {
        int n = arr.length;
        int[] nextGreater = new int[n];
        Deque<Integer> stack = new ArrayDeque<>();
        //  Map<Integer, Integer> nextGreaterMap = new HashMap<>();
        // Initialize the result array with -1 (default when no greater element found)
        for (int i = 0; i < n; i++) {
            nextGreater[i] = -1;
        }

        for (int i = 0; i < n; i++) {
            while (!stack.isEmpty() && arr[i] > arr[stack.peek()]) {
                int prevIndex = stack.pop();
                nextGreater[prevIndex] = arr[i];
            }
            stack.push(i);
        }
        return nextGreater;
    }

    public static void main(String[] args) {
        int[] arr = { 4, 2, 10, 7, 6 };

        int[] nextGreater = findNextGreaterElements(arr);
        for (int i = 0; i < arr.length; i++) {
            System.out.println("Next Greater Element for " + arr[i] + " is " + nextGreater[i]);
        }
    }
}
