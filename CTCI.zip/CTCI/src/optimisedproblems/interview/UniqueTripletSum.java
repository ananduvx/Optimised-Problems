package optimisedproblems.interview;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Asked in Altimetrik. Unique triplet sum equals to 0.
 * O(n2).
 * @author Anand
 *
 */
public class UniqueTripletSum {
    public List<List<Integer>> findTriplets(int[] nums) {
        List<List<Integer>> result = new ArrayList<>();
        Arrays.sort(nums);

        for (int i = 0; i < nums.length - 2; i++) {
            if (i == 0 || (i > 0 && nums[i] != nums[i - 1])) {
                //will do the binary search. 
                int left = i + 1, right = nums.length - 1, target = -nums[i];
                while (left < right) {
                    int sum = nums[left] + nums[right];
                    if (sum == target) {
                        result.add(Arrays.asList(nums[i], nums[left], nums[right]));
                        //check the nearest element to skip the duplicate...
                        while (left < right && nums[left] == nums[left + 1])
                            left++;
                        while (left < right && nums[right] == nums[right - 1])
                            right--;
                        left++;
                        right--;
                    } else if (sum < target) {
                        left++;
                    } else {
                        right--;
                    }
                }
            }
        }

        return result;
    }

    public static void main(String[] args) {
        UniqueTripletSum finder = new UniqueTripletSum();
        int[] nums = { -1, 0, 1, 2, -1, -4 };
        List<List<Integer>> triplets = finder.findTriplets(nums);

        for (List<Integer> triplet : triplets) {
            System.out.println(triplet);
        }
    }
}
