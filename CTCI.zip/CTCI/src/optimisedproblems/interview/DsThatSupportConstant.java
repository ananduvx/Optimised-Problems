package optimisedproblems.interview;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class DsThatSupportConstant {
    private ArrayList<Integer> arr; // A resizable array to hold the elements
    private Map<Integer, Integer> map; // A hash map to store the indexes of elements in arr
    public DsThatSupportConstant() {
        arr = new ArrayList<>();
        map = new HashMap<>();
    }

    // Method to add an element to the data structure
    public void add(int x) {
        if (!map.containsKey(x)) {
            int index = arr.size();
            arr.add(x);
            // And store its index in the hash map
            map.put(x, index);
        }
    }

    public void remove(int x) {
        if (map.containsKey(x)) {
            // Else remove element from the hash map and get its index in the array
            int index = map.get(x);
            map.remove(x);
            // Swap the element with the last element in the array and remove the last element
            int last = arr.size() - 1;
            arr.set(index, arr.get(last));
            arr.remove(last);
            // Update the hash map with the new index of the element that was swapped with the last element
            map.put(arr.get(index), index);
        }
    }

    public int search(int x) {
        if (map.containsKey(x)) {
            return map.get(x);
        }
        // Else return -1
        return -1;
    }
    
    public int getRandom() {
        Random rand = new Random();
        // Generate a random index from 0 to size - 1 of the array
        int randomIndex = rand.nextInt(arr.size());
        // Return the element at the randomly picked index
        return arr.get(randomIndex);
    }

    public static void main(String[] args) {
        DsThatSupportConstant ds = new DsThatSupportConstant();
        ds.add(10);
        ds.add(20);
        ds.add(30);
        ds.add(40);
        System.out.println(ds.search(30)); // Output: 2
        ds.remove(20);
        ds.add(50);
        System.out.println(ds.search(50)); // Output: 3
        System.out.println(ds.getRandom()); // Output: A random element from the array
    }
}
