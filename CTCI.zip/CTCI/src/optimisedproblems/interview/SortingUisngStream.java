package optimisedproblems.interview;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class SortingUisngStream {

    /**
     * 
     * findFirst(), findAny() max min and similar operation return Optional.
     * 
     * Stream api to sort the employee based on name and age.
     */
//listEmployee.stream()
//.sorted(Comparator.comparing(Employee ::getFirstName)
//.thenComparingInt(Employee::getAge))
////.map(a-> Collections.sort(a.getFirstName())
//.collect(Collectors.toList());

    /**
     * stream api to use partitioningBy to get even number and odd number.
     */
    List<Integer> numbers = IntStream.rangeClosed(1, 10).boxed().collect(Collectors.toList());

    Map<Boolean, List<Integer>> partitionedNumbers = numbers.stream()
            .collect(Collectors.partitioningBy(n -> n % 2 == 0));
    List<Integer> evenNumbers = partitionedNumbers.get(true);
    List<Integer> oddNumbers = partitionedNumbers.get(false);

    /**
     * 
     * Find the second maximum using Stream API
     */
    Optional<Integer> secondMax = numbers.stream().distinct() // Remove duplicates
            .sorted((a, b) -> Integer.compare(b, a)) // Sort in descending order
            .skip(1) // Skip the first element (maximum)
            .findFirst(); // Get the first element (second maximum)
//            .orElse(null); // Handle the case when there's no second maximum

    /**
     * Program to get employee with maximum salary using stream api. maxBy or minBy of collecters method.
     */
//    Optional<Employee> employeeWithMaxSalary = employees.stream()
//            .max(Comparator.comparingDouble(Employee::getSalary));

//    or
//    List.stream().sorted(Comparator.comparingInt(Employee:: getSalary)).reversed()
//    .limit(1).collect(Collecters.toList());

    // Best Approach
    // Find the employee with the maximum salary using Collectors.maxBy
//    Optional<Employee> employeeWithMaxSalary = employees.stream()
//            .collect(Collectors.maxBy(Comparator.comparingDouble(Employee::getSalary)));

}