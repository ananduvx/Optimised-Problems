package optimisedproblems.interview.newpackage;

import java.util.HashMap;
import java.util.Map;

public class HighestAverageScore {
    public static void main(String[] args) {
        String[][] input = {{"Bob","87"}, {"Mike", "35"},{"Bob", "52"}, {"Jason","35"}, {"Mike", "55"}, {"Jessica", "99"}};
        double result = findPersonWithMaxAverage(input);
        System.out.println(result);
    }

    private static double findPersonWithMaxAverage(String[][] input) {
        Map<String, int[]> personData = new HashMap<>();
        String maxAveragePerson = "";
        double maxAverage = Double.MIN_VALUE;

        for (String[] person : input) {
            String name = person[0];
            int score = Integer.parseInt(person[1]);

            personData.putIfAbsent(name, new int[] { 0, 0 });
            int[] data = personData.get(name);
            data[0] += score; // Total score
            data[1]++; // Count

            double average = (double) data[0] / data[1];

            if (average > maxAverage) {
                maxAverage = average;
                maxAveragePerson = name;
            }
        }
       System.out.println(personData);
        return maxAverage;
    }
}
