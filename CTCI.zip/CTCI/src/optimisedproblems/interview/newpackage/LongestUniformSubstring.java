package optimisedproblems.interview.newpackage;

public class LongestUniformSubstring {

    public static int[] findLongestUniformSubstring(String input) {
        int start = 0;
        int maxLength = 1;
        int currentStart = 0;
        int currentLength = 1;

        for (int i = 1; i < input.length(); i++) {
            if (input.charAt(i) == input.charAt(i - 1)) {
                currentLength++;
            } else {
                currentStart = i;
                currentLength = 1;
            }

            if (currentLength > maxLength) {
                start = currentStart;
                maxLength = currentLength;
            }
        }
        return new int[] { start, maxLength };
    }

    public static void main(String[] args) {
        String input = "aabbbbccdddeee";
        int[] result = findLongestUniformSubstring(input);

        System.out.println("Initial Index: " + result[0]);
        System.out.println("Length: " + result[1]);
    }

}
