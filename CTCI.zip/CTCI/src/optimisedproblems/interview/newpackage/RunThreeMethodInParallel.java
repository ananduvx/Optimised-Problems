package optimisedproblems.interview.newpackage;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class RunThreeMethodInParallel {
    public static void main(String[] args) {
        ExecutorService executorService = Executors.newFixedThreadPool(3);
        // Run three methods in parallel
        CompletableFuture<Void> method1 = CompletableFuture.runAsync(() -> method1());
        CompletableFuture<Void> method2 = CompletableFuture.runAsync(() -> method2());
        CompletableFuture<Void> method3 = CompletableFuture.runAsync(() -> method3());

        // Wait for all methods to complete
        CompletableFuture<Void> allOf = CompletableFuture.allOf(method1, method2, method3);

        try {
            allOf.get(); // Wait for all methods to finish
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }

        executorService.shutdown();
    }

    private static void method1() {
        System.out.println("Method 1 is running.");
        // Your method logic here
    }

    private static void method2() {
        System.out.println("Method 2 is running.");
        // Your method logic here
    }

    private static void method3() {
        System.out.println("Method 3 is running.");
        // Your method logic here
    }
}