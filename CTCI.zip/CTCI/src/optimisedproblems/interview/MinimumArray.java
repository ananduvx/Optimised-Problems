package optimisedproblems.interview;

public class MinimumArray {


public static int MinimumSubArraySum(int arr[], int target){
    int currentSum =arr[0];
    int  count =1;
    for(int i=1; i< arr.length; i++){
      if(currentSum < target){
          currentSum += arr[i];
          count++;
      }
      else if(currentSum == target) {
          return count;
      }
      else {
          currentSum = 0;
          count =1;
      }
    }
   return count;
   }
public static void main(String args[]) {
    int n[] = {2,3,1,2,4,3};
    int target = 2;
   int count =  MinimumSubArraySum(n,target);
   System.out.println(count);
    
}

}