package optimisedproblems.interview;

import java.util.PriorityQueue;

/**
 * 
 * @author Anand
 *
 */
public class LastStoneWeight {
    public static int lastStoneWeight(int[] stones) {
        // Create a max heap to store stone weights in descending order
        PriorityQueue<Integer> maxHeap = new PriorityQueue<>((a, b) -> b - a);

        // Initialize the max heap with the stone weights
        for (int stone : stones) {
            maxHeap.offer(stone);
        }           
        // Continue smashing stones until there is either one stone left or the heap is empty
        while (maxHeap.size() > 1) {
            int stone1 = maxHeap.poll();
            int stone2 = maxHeap.poll();

            if (stone1 != stone2) {
                maxHeap.offer(Math.abs(stone1 - stone2));
            }
        }

        // Return the weight of the last stone or 0 if there are no stones left
        return maxHeap.isEmpty() ? 0 : maxHeap.peek();
    }

    public static void main(String[] args) {
        int[] stones = { 2, 7, 4, 1, 8, 1 };
        int result = lastStoneWeight(stones);
        System.out.println("The weight of the last stone is: " + result);
    }
}
