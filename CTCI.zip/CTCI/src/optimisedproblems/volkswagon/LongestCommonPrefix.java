package optimisedproblems.volkswagon;

public class LongestCommonPrefix {
    
    public static String longestCommonPrefix(String[] strs) {
        if (strs == null || strs.length == 0) {
            return "";
        }
        // Start with the first string as a potential common prefix.
        String prefix = strs[0];

        for (int i = 1; i < strs.length; i++) {
            //Index of will return the index else it will return -1
            while (strs[i].indexOf(prefix) != 0) {
                // While the current string doesn't start with the current prefix,
                // shorten the prefix by removing the last character.
                prefix = prefix.substring(0, prefix.length() - 1);
            }
        }

        return prefix;
    }

    public static void main(String[] args) {
        String arr[] = {"flow","flower","flowing"};
    System.out.println(longestCommonPrefix(arr));
    }

}
