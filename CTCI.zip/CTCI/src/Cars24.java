import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Cars24 {

    
    public static void main(String [] args) {
        Integer [] b = {1,2,3,4,5,6,2};
        List<Integer> numList;
        Map<Integer,Integer> numMap = Arrays.asList(b).stream()
                .distinct()
        .filter(a-> a%2 == 0)      
        .collect(Collectors.toMap(a->a,a->a,(v1,v2)->v1));
        
        
        
//        List<Integer> 
//        filter even 
//        collect to map <>
//        deadletter queues 
        
        
        
//        Emp
//        id
//        name 
//        mId  //  id of another employee 
        
//        id name mId mName
         
//        select id, name from employee where id =1 
//        select id, name,mId , mName from ( select * from employee inner join manager);
//        
//        select * from employee where id = 1 
        
//        mysql Engines
        //
    }
}
