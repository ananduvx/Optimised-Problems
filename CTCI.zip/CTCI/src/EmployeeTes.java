import java.util.Comparator;
import java.util.Set;
import java.util.stream.Collectors;

public class EmployeeTes {
    
    
    
    public EmployeeTes() {
        super();
    }

    public static String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        EmployeeTes.firstName = firstName;
    }

    public static String getLastName() {
        return LastName;
    }

    public void setLastName(String lastName) {
        LastName = lastName;
    }

    public int getSalary() {
        return salary;
    }

    public void setSalary(int salary) {
        this.salary = salary;
    }

    private static String firstName;
    private static String LastName;
    private int salary;

    public static void main(String[] args) {
        Employee e1 = new Employee("anand", "prakash",40);
        Employee e2 = new Employee("anand", "prakash", 40);

        Set<Employee> employeeList = null;
//        employeeList.add(e2);
        
        System.out.println(e1.equals(e2));
        
        
//        == and .equals
//
        employeeList.stream()
                .sorted(Comparator.comparing(Employee::getFirstName)
                        .thenComparing(Employee :: getLastName)
                        )
                .collect(Collectors.toList());

    }

}
