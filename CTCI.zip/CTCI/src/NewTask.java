
public class NewTask {
//lexicographically sorted.
//  i/p-    123654 
//  o/p -   124356
//       123456  
    // 
//    321
//    123 
    
      //find next greater element to that ele. 
    // 4, 5, 2 ,25 
    // 4 , 27 , 5, 28
    
    public static int[] lexicographicallySorted(int arr[]) {
        
        
        
        return arr;  
    }
    
    
    public static void main(String[] args) {

    }

}
