import java.util.HashMap;
import java.util.Map;

public class AutoTest {

//    public static Map<Character, Integer> countChar(String str) {
//        Map<Character, Integer> countMap = new HashMap<>();
//        for (char c : str.toCharArray()) {
//            countMap.put(c, countMap.getOrDefault(c, 0) + 1);
//        }
//        return countMap;
//
//    }
    
    
//    public static String longestCommon(String str) {
//        Map<Character, Integer> charIndex = new HashMap<>();
//        int start = 0;
//        int maxLen = 0;
//        int startMax =0;
//        for (int i = 0; i < str.length(); i++) {
//            char c = str.charAt(i);
//            if (charIndex.containsKey(c)) {
//                start = Math.max(start, charIndex.get(c) + 1);
//            }
//            charIndex.put(c, i);
//            if (i - start + 1 > maxLen) {
//                maxLen = i - start + 1;
//                startMax = start;
//            }
//
//        }
//
//        return str.substring(startMax, maxLen+startMax);
//
//    }
//
//    public static void main(String[] args) {
//        String str = "BBCDEFGABEF";
////        abca
//        System.out.println(countChar(str));
//        System.out.println(longestCommon(str));
//
//    }
    
    // can we create 
    
    
    public static  class Singleton{
        private String s;
        private Singleton() {
            
        }
        static Singleton singleton;
        public static Singleton getInstace() {
            if(singleton == null) {
                return new Singleton();
            }
            
            return null;
        }     
    }
    
//    @SpringBootApplication 
//     Request scope 
    // singleton 
    //Primary  
    //  ArrayList internal working random access into this.  
    //  
    
    
    
    
    
    
    

}
