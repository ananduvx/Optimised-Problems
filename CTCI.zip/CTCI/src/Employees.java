import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

public final class Employees {
    private final Long id;
    private final String firstName;
    private final List<String> lastName;
    
    
    
    
   @Override
   public boolean equals(Object o) {
       if(this==o) return true;
       
    return false;
       
   }
//   @Override
//   public int hashCode() {
//       return Objects.hash(id,firstName,lastName);
//   }
    
   
//   try {
//       
//       throw new 
//       
//   }catch(Exception e) {
//       
//   }
   
//   back processing
   
   
    
    
}
