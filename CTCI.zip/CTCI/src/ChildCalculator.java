
public class ChildCalculator extends Calculator {
    
public float add(float a, float b) {
    return a+b;
}



public static void main(String[] args) {
    Calculator c = new ChildCalculator();
    
    
//    c.add(1.2 , 1.3);
    c.add(1, 1);
    
  c.divide(1, 0);
}





}


