import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class Practice4 {

//    You have been given a set of coins. Write a program to find the minimum number of coins required to
//    match the given amount value.
//
//    Example
//    You have coins 1, 5, 7, 9, 11. Calculate minimum number of coins required for any input amount 250. 
//
//    Example:
//    AMount 6 will require 2 coins (1, 5). 
//    Amount 25 will require 3 coins (5, 9, 11).
//    has context menu
    
    public static Map<Integer, Integer> minCoinVal(int [] coins, int amount) {
        Map<Integer, Integer> resultMap = new HashMap<>();
        Map<Integer, Integer> coinCount = new HashMap<>();
        
        int [] dp = new int[amount+1];
        Arrays.fill(dp, Integer.MAX_VALUE);
        dp[0]= 0;
        for(int coin:  coins) {
            for(int i = coin; i<= amount; i++) {
                if(dp[i-coin] != Integer.MAX_VALUE && dp[i-coin] +1 <dp[i]){
                    dp[i] = dp[i-coin] +1 ;
                    coinCount.put(i, coin);   
                }
            }
        }
        if(dp[amount] == Integer.MAX_VALUE) {return null;}
        int remainCoins = amount;
        while(remainCoins >0) {
            int coin = coinCount.get(remainCoins);
            resultMap.put(coin, resultMap.getOrDefault(coin, 0)+1);
            remainCoins -=coin;    
        }
 
        return resultMap;
    }
    
    
    
    public static void main(String[] args) {
     int[] arr = {1, 5, 7, 9, 11};
     int amount = 6;
     System.out.println(minCoinVal(arr,amount));
    }

}
// 1 2 3 4 
// 1
// 5
// 7