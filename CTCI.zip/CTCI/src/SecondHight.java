import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Stream;

public class SecondHight {

    public static void main(String[] args) {
        int arr[] = { 100, 2, 1000, -77, 5, 6, 7, 89 };
        
//        Remove common elements from both the arys
        int arr1[] = {1,2,3,4,5,6,7}; 
//        --- 1,2,3  
           int arr2[] = {4,5,6,7,8,9,10,11,12 };
//        -- 8,9,10,11,12
        
        removeDup(arr1,arr2);
        

        int secHighest = secondHighest(arr);
        System.out.println(secHighest);

    }

    private static void removeDup(int[] arr1, int[] arr2) {
        int i = 0;
        int j=0;
        List<Integer> arr1List = new ArrayList<>();
        while(i<arr1.length && j< arr2.length) {
            while
            
            if(arr1[i] != arr2[j]) {
                arr1List.
            }
            
        }
        
        
        
        
        
        
    }

    private static int secondHighest(int[] arr) {
        int high = 0;
        int secHigh = 0;

        for (int i = 0; i < arr.length; i++) {
            if (arr[i] > high) {
                secHigh = high;
                high = arr[i];
            } else if (arr[i] > secHigh && arr[i] != high) {
                secHigh = arr[i];
            }

        }
        return secHigh;
    }

    
    
    
    
}
