
public class ReplaceVowels {
    
    
    
   
           public static String rplaceVowels(String str){
               String result = "";
               
           for(int i=0; i<str.length(); i++){
           char charTocheck= str.charAt(i); 
           if(isVowel(charTocheck)) {
               charTocheck = 'z';
//                       getNextVowel(charTocheck);
               result+
               return new String();
               
           }
            
           }
 
           }
           
           private static char getNextVowel(char charTocheck) {
            
               switch(charTocheck) {
               
               }
               
               
               
            return 0;
        }

        private static boolean isVowel(char charTocheck) {
            return "aeiouAEIOU".indexOf(charTocheck) != -1;
        }

        public static void main(String str[]) {
//               hello World
//               hillu wurld
               System.out.println(rplaceVowels("hello World"));
           }

}
