
// Given a sorted array of integers A of size N and an integer B.

// array A is rotated at some pivot unknown to you beforehand.

// (i.e., 0 1 2 4 5 6 7 might become 4 5 6 7 0 1 2 ).

// You are given a target value B to search. If found in the array, return its index otherwise, return -1.

// You may assume no duplicate exists in the array.

// NOTE: Users are expected to solve this in O(log(N)) time.

// A : [ 9, 10, 3, 5, 6, 8 ]
// a

// B : 5 || Output: 3

//   int i=0;
//   int end = len-1
//           target = 5
//           while(i<=end) {
//               mid =
//           if(num[mid] == tare) {}
//               if(num[i]<num[mid]) {
//                   if(target>)
//               }
//           }

public class NewProblem {
    /**
     * Method to search in rotated sorted array
     * 
     * @param nums
     * @param target
     * @return
     */
    public static int search(int[] nums, int target) {
        int left = 0;
        int right = nums.length - 1;
//running a loop from start to end.
        while (left <= right) {
            int mid = (left + right) / 2;
            // Happy scenario.
            if (nums[mid] == target) {
                return mid;
            }
            // comparing start and mid element
            // why because it is rotated so might be the case start element is < mid ones
            if (nums[left] < nums[mid]) {
                // this condition means left half is sorted. so will search in it.
                if (target >= nums[left] && target < nums[mid]) {
                    // if the above condition satisfies i will make right as mid-1 and continue search.
                    right = mid - 1;
                } else {
                    // else i will keep searching in the right array making left = mid+1
                    left = mid + 1;
                }
            } else {
                // if left is greater then compare the target element with mid ones
                // checking the target value with the middle ones and last ones.
                if (target > nums[mid] && target <= nums[right]) {
                    left = mid + 1;
                } else {
                    right = mid - 1;
                }
            }
        }

        return -1;
    }

    public static void main(String args[]) {
        int[] arr = { 9, 10, 3, 5, 6, 8 };
        System.out.println(search(arr, 5));

    }
}
