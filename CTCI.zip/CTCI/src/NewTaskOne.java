import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class NewTaskOne {

    
    public static void main(String[] args) {

        String [] arr = {"raju","ravi","venkat","rajesh"};
        //start with r 
        //start with name - lenght
        Map<Integer,List<String>> arrayGroup =  
                Arrays.asList(arr).stream()
                .filter(name->name.startsWith("r"))
                .collect(Collectors.groupingBy(String::length));
        
        arrayGroup.forEach((length,value)->{
            value.forEach(name->{
                System.out.println(" name is: "+name +" length is: "+ length);
            });
            
        });
        
        
        
    }

}
