import java.util.ArrayList;
import java.util.List;

public class Practic2 {
//    Given a sorted Array of integers, an integer X which is already present
//    in array and an integer K, find K nearest (based on difference not on index) elements to X in the array. 
//
//    Arr = {2, 5, 8, 10, 13, 17, 19, 25, 27, 32}
//    X = 19
//    K = 4
//
//    O/P: {13, 17, 25, 27}'
    
    public static int[] nearestArray(int arr[],int num, int k) {
        List<Integer> result = new ArrayList<>();
        int index = 0;
        int left =0;
        int right = arr.length;
        while(left<right){
            int mid = left+ (right-left)/2;
            if(arr[mid]> num) {
                right = mid;
            }else if(arr[mid]<num) {
                left = mid;
            }else if(arr[mid] == num) {
                index = mid;
            }            
            
        }
        
        
        
        
        return arr;
        
    }
    
    
    
    
    

}
