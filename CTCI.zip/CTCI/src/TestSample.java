import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class TestSample {
    
    
    
//    "Java", "Python", "C#", "HTML", "Kotlin", "C++", "COBOL", "C"

    public static void main(String[] args) {
     
       String [] stat=  {"Pen", "Eraser", "Note Book", "Pen", "Pencil", "Stapler", "Note Book", "Pencil", "Pen"};
       String [] techStack = {"Java", "Python", "C#", "HTML", "Kotlin", "C++", "COBOL", "C"};
      Map<String,Long> mapCount =  Arrays.asList(stat).stream()
         .collect(Collectors.groupingBy(a->a,Collectors.counting()));
      
      System.out.println(mapCount);
      
      
      Map.Entry<String, Long> maxEntry = mapCount.entrySet()
              .stream()
              .max(Map.Entry.comparingByValue())
              .orElseGet(null);
             System.out.println(maxEntry); 
      
      
      List<String> str = Arrays.asList(techStack).stream()
      .sorted((str1,str2)-> Integer.compare(str1.length(),str2.length()))
              .collect(Collectors.toList());
      
      System.out.println(str);
             
             
             
             
      

    }

}
