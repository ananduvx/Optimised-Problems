
public class PracticeDeolite {
// create an example of deadlock 
    
    
    public static void main(String args[]) {
        final Object res1 = new Object();
        final Object res2 = new Object();
        Thread t1 = new Thread(
                ()->{
                  synchronized (res1) {  
                }     
                    
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
       
        synchronized (res2) {
            
        }
                });
        
        Thread t2 = new Thread(
                ()->{
                  synchronized (res2) {  
                      
                      //
                }     
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        synchronized (res1) {
            
        }
                }); 
        t1.start();
        t2.start();
    } 
    
}

//HashSet 
//HashTable  -- synchronised
//jet garbage collector -- 
// 



//Employee table 3rd highsest salary

//select distinct salary from employee order By salary Desc Limit 1 offset 2;





