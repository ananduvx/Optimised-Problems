
public class ReverseArray {
//    [0,1,2,3,4,5] => [5,4,3,2,1,0]
    public static void main(String args[]) {
        int [] arr = {0,1,2,3,4,5};
        
        int []result = reverseArray(arr);
        for(int num : result) {
            System.out.println(num);  
        }
        
    }

private static int[] reverseArray(int[] arr) {
    int left =0;
    int right  = arr.length-1;
    while(left<right) {
        swap(arr,left,right);
        left ++;
        right --;
    }
    
    return arr;
}

private static void swap(int[] arr, int left, int right) {
    int temp = arr[left];
    arr[left] = arr[right];
    arr[right] = temp;  
}
    
}
