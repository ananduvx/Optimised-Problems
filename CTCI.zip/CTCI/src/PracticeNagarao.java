
import java.util.Map;
import java.util.stream.Collectors;

/**
 * TO map character to count of a String.
 * @author Anand
 *
 */
public class PracticeNagarao {

    // string count freq. of each character in stream
    public static void main(String args[]) {
        String str = "anand";

        Map<Character, Long> charCountMap =
//        Arrays.asList(str.toCharArray())
//        .stream()
                str.chars().mapToObj(a -> (char) a).collect(Collectors.groupingBy(a -> a, Collectors.counting()));
        System.out.println(charCountMap);

    }

}
