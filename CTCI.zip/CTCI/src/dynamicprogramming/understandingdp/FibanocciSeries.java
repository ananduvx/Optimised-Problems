package dynamicprogramming.understandingdp;

/**
 * f(n) = f(n-1)+f(n-2); using tabulation method.
 * 
 * @author Anand
 *
 */
public class FibanocciSeries {
    static int term[] = new int[1000];
    public static int fibannoci(int n) {
        if (n <= 1)
            return n;
        if (term[n] != 0) {
            return term[n];
        } else {
            term[n] = fibannoci(n - 1) + fibannoci(n - 2);
            return term[n];
        }
    }

    public static void main(String[] args) {
        int n = 6;
        System.out.println(fibannoci(n));
    }
}
