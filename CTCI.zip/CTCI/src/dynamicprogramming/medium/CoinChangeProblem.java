package dynamicprogramming.medium;

import java.util.Arrays;

public class CoinChangeProblem {
    /**
     * By using iteration update the count based on the index of the sum. T.c == O(n*sum) for both the cases.
     * 
     * @param coins
     * @param sum
     * @return
     */
    public static int coinChangeCombinations(int[] coins, int sum) {
        // initially all the value in the array will be 0.
        int[] dp = new int[sum + 1];
        dp[0] = 1;
        for (int coin : coins) {
            for (int i = coin; i <= sum; i++) {
                dp[i] += dp[i - coin];
            }
        }

        return dp[sum];
    }

    /**
     * By using bottom-up approach memorization and knapsack problem issue thinking .
     * 
     * @param a
     * @param sum
     * @param n
     * @return int
     */
    public static int knapsackCoinChange(int[] coins, int sum) {
        int n = coins.length;
        // +1 because the indexing start from 0.
        int[][] dp = new int[n + 1][sum + 1];
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= sum; j++) {
                // compare current weight and current capacity if difference between capacity and weight diff is -ve
                if (coins[i - 1] > j) {
                    dp[i][j] = dp[i - 1][j];
                } else {
                    // weight is equal to capacity or less than capacity then find the max and put the val.
                    dp[i][j] = Math.max(dp[i - 1][j], coins[i - 1] + dp[i - 1][j - coins[i - 1]]);
                }
            }
        }
        return dp[n][sum];
    }

    /**
     * using GFG programming.
     * 
     * @param a
     * @param sum
     * @param n
     * @return
     */
    static int coinchange(int[] a, int sum, int n) {
        int[][] dp = new int[n + 1][sum + 1];
        for (int[] row : dp)
            Arrays.fill(row, -1);
        if (sum == 0)
            return dp[n][sum] = 1;
        if (n == 0)
            return 0;
        // checking in the dp array.
        if (dp[n][sum] != -1)
            return dp[n][sum];
        if (a[n - 1] <= sum) {
            // Either Pick this coin or not
            return dp[n][sum] = coinchange(a, sum - a[n - 1], n) + coinchange(a, sum, n - 1);
        } else // We have no option but to leave this coin
            return dp[n][sum] = coinchange(a, sum, n - 1);
    }

    public static void main(String[] args) {
        int[] coins = { 1, 2, 3 };
        int sum = 5;
        int numCombinations = knapsackCoinChange(coins, sum);
        System.out.println("Number of distinct ways to make " + sum + " using the given coins: " + numCombinations);
    }
}