package dynamicprogramming.medium;

/**
 * https://monicagranbois.com/knapsack-algorithm-visualization/
 * implementing 0/1 knapsack problem.
 * 
 * @author Anand
 *
 */
public class KnapsackProblem {
    /**
     * create dp array[n+1][capacity+1], iterate two loop one for weight array i.e i other for capacity i.e j. now check
     * for the capacity at j and weight at i-1 as weight having 0 indexing and loop start at 1. if(j>=w[i-1]){ find the
     * differece between capacity and weight at that point and add value to that dp[i-1][cap-weight] dp[i][j] = max(dp[i
     * - 1][j], values[i - 1] + dp[i - 1][j - weights[i - 1]]) }else{ dp[i][j] = dp[i-1][j]; }
     * 
     * @param weights
     * @param values
     * @param capacity
     * @return int
     */
    public static int knapsack(int[] weights, int[] values, int capacity) {
        int n = weights.length;
        // +1 because the indexing start from 0.
        int[][] dp = new int[n + 1][capacity + 1];

        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= capacity; j++) {
                // compare current weight and current capacity if difference between capacity and weight diff is -ve
                if (weights[i - 1] > j) {
                    dp[i][j] = dp[i - 1][j];
                } else {
                    // weight is equal to capacity or less than capacity then find the max and put the val.
                    dp[i][j] = Math.max(dp[i - 1][j], values[i - 1] + dp[i - 1][j - weights[i - 1]]);
                }
            }
        }
        return dp[n][capacity];
    }

    public static void main(String[] args) {
        int[] weights = { 1, 3, 4, 6 }; // Example item weights
        int[] values = { 20, 30, 10, 50 }; // Example item values
        int capacity = 10; // Example knapsack capacity

        int maxVal = knapsack(weights, values, capacity);
        System.out.println("Maximum value that can be achieved: " + maxVal);
    }
}