package dynamicprogramming.medium;

/**
 * Cn = 2n!/ (n+1)! *n!
 * 
 * @author Anand
 *
 */
public class CatalanNumber {
    /**
     * finding catalan numbet using memoization
     * 
     * @param n
     * @return
     */
    public static int findCatalanNumber(int n) {
        int[] catalan = new int[n + 1];
        catalan[0] = 1;

        for (int i = 1; i <= n; i++) {
            for (int j = 0; j < i; j++) {
                catalan[i] += catalan[j] * catalan[i - j - 1];
            }
        }
        return catalan[n];
    }

    /**
     * By using binomial Coeff.
     * 
     * @param n
     * @param k
     * @return
     */
    static long binomialCoeff(int n, int k) {
        long res = 1;
        // Since C(n, k) = C(n, n-k)
        if (k > n - k) {
            k = n - k;
        }
        for (int i = 0; i < k; ++i) {
            res *= (n - i);
            res /= (i + 1);
        }

        return res;
    }

    static long catalan(int n) {
        // Calculate value of 2nCn
        long c = binomialCoeff(2 * n, n);
        // return 2nCn/(n+1)
        return c / (n + 1);
    }

    public static void main(String[] args) {
        for (int i = 0; i < 10; i++) {
            System.out.print(findCatalanNumber(i) + " ");
        }
    }
}
