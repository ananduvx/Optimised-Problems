package dynamicprogramming.medium;
/**
 * 
 * @author Anand
 *
 */
public class BinomialCoefficient {
    /**
     * Find nck..
     * @param n
     * @param k
     * @return int
     */
        public static int calculateBinomialCoefficient(int n, int k) {
            int[][] dp = new int[n + 1][k + 1];
            for (int i = 0; i <= n; i++) {
                dp[i][0] = 1;
            }
            // Calculate binomial coefficient using dynamic programming
            for (int i = 1; i <= n; i++) {
                for (int j = 1; j <= k && j <= i; j++) {
                    dp[i][j] = dp[i - 1][j - 1] + dp[i - 1][j];
                }
            }
            return dp[n][k];
        }
        public static void main(String[] args) {
            int n = 5; // Example value of n
            int k = 2; // Example value of k
            int binomialCoefficient = calculateBinomialCoefficient(n, k);
            System.out.println("Binomial Coefficient C(" + n + ", " + k + ") = " + binomialCoefficient);
        }
    }
