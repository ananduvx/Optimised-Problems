package dynamicprogramming.medium;

/**
 * npr = n!/(n-r)! ncr = n!/r!(n-r)!
 * 
 * @author Anand
 *
 */
public class PermutationCoefficient {
    /**
     * PNr //
     * @param n
     * @param r
     * @return int
     */
    private static int permutationCoeffRecursive(int n, int r) {
        int[][] dp = new int[n + 1][r + 1];
        // Check if the result is already memorized
        if (dp[n][r] != 0) {
            return dp[n][r];
        }
        // Base cases
        if (r == 0) {
            return 1;
        }
        if (r > n) {
            return 0;
        }
        // Recursive call with memorization
        dp[n][r] = permutationCoeffRecursive(n - 1, r ) + (r * permutationCoeffRecursive(n - 1, r-1));

        return dp[n][r];
    }

    public static void main(String[] args) {
        int n = 10; // Example value of n
        int r = 2; // Example value of r

        int permutationCoefficient = permutationCoeffRecursive(n, r);
        System.out.println("Permutation Coefficient P(" + n + ", " + r + ") = " + permutationCoefficient);
    }
}
