import java.util.HashMap;
import java.util.Map;

public class KpmgTest2 {
//    "asdfasdfbhnjiofdeefs";
    //asdf 
    
    public static void main(String args[]) {
        
        String str = "asdfasdfbhnjiofdeefs";
        System.out.println(longestSubstring(str));
        
        
    }

private static String longestSubstring(String str) {
       Map<Character,Integer> charIndex = new HashMap<>();
       int n = str.length();
       int start =0;
       int end =0;
       int maxLen =0;
       int maxStart =0;
       while(end<n) {
           if(charIndex.containsKey(str.charAt(end)) && charIndex.get(str.charAt(end)) >= start) {
               start = charIndex.get(str.charAt(end))+1;
           }
           charIndex.put(str.charAt(end), end);
           int currentLenght = end - start+1;
           if(currentLenght> maxLen) {
               maxLen = currentLenght; 
               maxStart = start;
           }
           end++;
       }
      
    return str.substring(maxStart, maxStart+maxLen);
}
    
    
    
    
    
}
