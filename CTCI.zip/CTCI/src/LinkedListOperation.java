

/**
 * This class will add and remove the Node to the linkList.
 * @author Anand
 *
 */
public class LinkedListOperation {
  private Node head;
    
  
  /**
   * Method to add a node. 
   * @param a
   */
    public void add(int a) {
        Node node1 = new Node(a);
        // If head is null then return;
        if(head==null) {
            head = node1;
        }else {
            Node curr = head;
            //Iterate to the last
            while(curr.next != null) {
                curr= curr.next;
            }
            curr.next = node1;
        }        
    }
    
    /**
     * Method to remove 
     * @param data
     */
    public void remove(int data) {
        
        /**
         * 1. if head == null then return nothing to remove
         * create a previous node and initialize it with null. 
         * head.data == data then move the pointer to next i.e head = head.next and return
         * then iterate to the loop and find the data.. 
         * if data is found then  assign previous with current 
         * and current will be current.next  
         * previous.next = curr.next; 
         */
        
    }
    public static void main(String[] args) {

    }

}



class Node {
    int data;
    Node next;

    public Node(int data, LinkedListOperation.Node node) {
        super();
        this.data = data;
        this.next = node;
    }
    public Node(int data) {
        super();
        this.data = data;
        this.next = null;
    }
}