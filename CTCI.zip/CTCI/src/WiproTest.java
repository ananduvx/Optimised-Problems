import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class WiproTest {

    public static void main(String[] args) {
        // top 5 by salary
        // name start with b

        List<Employee> empList = new ArrayList<>();
        empList.add(new Employee("Anand", "Prakash", 10));
        empList.add(new Employee("bikash", "Prakash", 20));
        empList.add(new Employee("mnand", "Prakash", 30));
        empList.add(new Employee("binay", "Prakash", 40));
        empList.add(new Employee("biswas", "Prakash", 50));
        empList.add(new Employee("bipin", "Prakash", 60));
        empList.add(new Employee("bipul", "Prakash", 70));

        List<Employee> result = empList.stream()
                .sorted(Comparator.comparing(Employee::getSalary).reversed())
                .limit(5)
                .filter(e->e.getFirstName().startsWith("b"))
//                .map(a -> a.getFirstName().startsWith("b"))
                .collect(Collectors.toList());
        
        for(Employee e : result) {
        System.out.println(e.getFirstName());

    }
    }

}
