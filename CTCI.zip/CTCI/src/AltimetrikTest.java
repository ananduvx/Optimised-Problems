
public class AltimetrikTest {

    
    
    
    public static void main(String[] args) {
    String s = "anand";
        
        System.out.println(removeDup(s));

    }

    private static String removeDup(String s) {
        String str = "";
       for(int i=0; i<s.length(); i++) {
           char currentChar = s.charAt(i);
           if(s.indexOf(currentChar) == s.lastIndexOf(currentChar) ) {
               return str+currentChar;
           }
       }
       return null;
    }

}
