import java.util.concurrent.ConcurrentHashMap;

public class DataProcessor {
    ConcurrentHashMap<Integer, String> dataMap = new ConcurrentHashMap<>();
    
  public void addRecord(int id, String data) {
      dataMap.put(id, data);
  }
  public String getData(int id) {
      if(dataMap.containsKey(id)) {
          return dataMap.get(id);          
      }
      return null;
  }
    
    public static void main(String[] args) {
        DataProcessor data = new DataProcessor();
        //Insert
        Thread t1 = new Thread(
                ()->{
                    data.addRecord(1, "Data 1");
                    data.addRecord(2, "Data 2");
                }
                );
        Thread t2 = new Thread(
                ()->{
                    data.addRecord(3, "Data 3");
                    data.addRecord(4, "Data 4");
                }
                );
        //Retrieve 
        Thread t3 = new Thread(
                ()->{
                   String res1 = data.getData(1);
                    String res2 = data.getData(4);
                    System.out.println("result1 is: "+res1+" result 2 is: "+res2);
                }
                );
        
        t1.start();
        t2.start();
        t3.start();
        
        try{
            t1.join();
            t2.join();
            t3.join();
        }catch (InterruptedException e) {
           System.out.println(e);
        }
    }

}
