package LinkedList;
/**
 * 
 * @author Anand
 *
 */
public class SumList {

    public static void main(String[] args) {

    }

}
