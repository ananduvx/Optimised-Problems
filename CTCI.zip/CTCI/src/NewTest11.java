import java.util.Stack;

public class NewTest11 { 
//    Input: s = "3[a]2[bc]"
//            Output: "aaabcbc"
//            Input: s = "3[a2[c]]"
//            Output: "accaccacc"
//            Input: s = "2[abc]3[cd]ef"
//            Output: "abcabccdcdcdef

    public static void main(String[] args) {
        
        String str = "3[a]2[bc]";
        System.out.println(printStr(str));

    }

    private static String printStr(String str) {
        StringBuilder result = new StringBuilder();
        Stack<Integer> countNum = new Stack<>();
        Stack<StringBuilder> stringStack = new Stack<>();
        int count =0; 
        for(char c: str.toCharArray()) {
            if(Character.isDigit(c)) {
                count = count*10+ c-'0';
                countNum.push(count);
            }else if(c =='[') {
//                countNum.push(count);
                count =0;
//                result.append(c);
                stringStack.push(result);
                result = new StringBuilder();
            }else if(c== ']') {
                StringBuilder temp = stringStack.pop();
                for(int i =0; i< countNum.pop(); i++) {
                    temp.append(result);
                }
                result = temp;
            }else {
                result.append(c);
            }
        }
       
        return result.toString();
    }
    
    
//    select salary, id from employee order by salary desc limit 1 offset 1;
    
    
    

}
