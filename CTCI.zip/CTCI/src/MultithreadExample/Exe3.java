package MultithreadExample;

public class Exe3 implements Runnable{
    

}
