package MultithreadExample;

public class Exe2 {

}
