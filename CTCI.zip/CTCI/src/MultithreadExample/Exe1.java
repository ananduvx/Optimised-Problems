package MultithreadExample;

public class Exe1 {

}
