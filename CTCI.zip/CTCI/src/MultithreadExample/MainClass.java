package MultithreadExample;

//Run 3 methods parallelly from 3 classes. Use Multithreading.
public class MainClass {

    
    public static void main(String[] args) {
        Thread t1 = new Thread("hi");
        Thread t2 = new Thread("hii");
        t1.start();
        System.out.println(System.currentTimeMillis());
        t2.start();
        System.out.println(System.currentTimeMillis());
        

    }
    
    
    
    
    //

}
